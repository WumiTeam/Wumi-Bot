import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import { createApp } from '../server/app';
import { loadConfig } from '../server/config';
import { createSession } from '../server/session';
import { JsonFileStore } from '../server/store';
import { defaultSave } from '../src/shared/saveSchema';

let failures = 0;
const ok = (cond: boolean, msg: string) => {
  console.log(cond ? 'OK  ' : 'FAIL', msg);
  if (!cond) failures++;
};
const listen = (s: http.Server) => new Promise<number>((r) => s.listen(0, '127.0.0.1', () => r((s.address() as AddressInfo).port)));

// ---------- Faux Discord (pour tester sans réseau) ----------
const USERS: Record<string, { id: string; username: string; global_name?: string }> = {
  alice: { id: '111111111111111111', username: 'alice', global_name: 'Alice' },
  bob: { id: '222222222222222222', username: 'bob' },
};
const fakeDiscord = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    res.setHeader('Content-Type', 'application/json');
    if (req.method === 'POST' && req.url === '/oauth2/token') {
      const p = new URLSearchParams(body);
      const valid = p.get('client_id') === '123' && p.get('client_secret') === 's3cret' && p.get('grant_type') === 'authorization_code';
      const code = p.get('code') ?? '';
      if (!valid || !USERS[code]) return void res.writeHead(400).end('{"error":"invalid_grant"}');
      return void res.end(JSON.stringify({ access_token: `at_${code}` }));
    }
    if (req.method === 'GET' && req.url === '/users/@me') {
      const u = USERS[(req.headers.authorization ?? '').replace('Bearer at_', '')];
      return u ? void res.end(JSON.stringify(u)) : void res.writeHead(401).end('{}');
    }
    res.writeHead(404).end('{}');
  });
});

(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'astro-'));
  fs.mkdirSync(path.join(tmp, 'dist'));
  fs.writeFileSync(path.join(tmp, 'dist', 'index.html'), '<h1>jeu</h1>');
  fs.writeFileSync(path.join(tmp, 'secret.txt'), 'TOP-SECRET');
  const dataFile = path.join(tmp, 'data', 'saves.json');

  const dPort = await listen(fakeDiscord);
  const cfg = loadConfig({
    SESSION_SECRET: 'test-secret-test-secret',
    DISCORD_CLIENT_ID: '123',
    DISCORD_CLIENT_SECRET: 's3cret',
    DISCORD_API_BASE: `http://127.0.0.1:${dPort}`,
    DATA_FILE: dataFile,
    DIST_DIR: path.join(tmp, 'dist'),
  } as NodeJS.ProcessEnv);
  const store = new JsonFileStore(cfg.dataFile);
  const server = createApp(cfg, store);
  const port = await listen(server);
  const base = `http://127.0.0.1:${port}`;

  const api = async (method: string, url: string, opts: { token?: string; body?: unknown; raw?: string } = {}) => {
    const r = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(opts.token ? { Authorization: `Bearer ${opts.token}` } : {}) },
      body: opts.raw ?? (opts.body === undefined ? undefined : JSON.stringify(opts.body)),
    });
    return { status: r.status, json: (await r.json().catch(() => ({}))) as any };
  };
  const login = async (code: string) => (await api('POST', '/api/token', { body: { code } })).json as { session: string; access_token: string; user: any };

  // --- Santé & accès sans jeton ---
  ok((await api('GET', '/api/health')).json.discordConfigured === true, 'santé : Discord configuré');
  ok((await api('GET', '/api/save')).status === 401, 'sauvegarde sans jeton → 401');
  ok((await api('GET', '/api/save', { token: 'n.importe.quoi' })).status === 401, 'jeton bidon → 401');
  ok((await api('POST', '/api/dev-login')).status === 404, 'dev-login désactivé par défaut');

  // --- Connexion ---
  ok((await api('POST', '/api/token', { body: { code: 'bad' } })).status === 401, 'mauvais code Discord → 401');
  ok((await api('POST', '/api/token', { body: {} })).status === 400, 'code manquant → 400');
  const alice = await login('alice');
  const bob = await login('bob');
  ok(!!alice.session && alice.access_token === 'at_alice' && alice.user.name === 'Alice', 'connexion Alice : session + access_token + nom affichable');
  ok(!('id' in alice.user), "l'identifiant Discord n'est pas renvoyé au client");

  // --- Sauvegarde ---
  ok((await api('GET', '/api/save', { token: alice.session })).json.save === null, 'nouvelle sauvegarde vide');
  const good = { ...defaultSave(), coins: 42, owned: ['beige', 'green'], selected: 'green', unlockedLevel: 2, bestTimes: { '1': 41230 }, bestStars: { '1': 3 } };
  ok((await api('PUT', '/api/save', { token: alice.session, body: good })).status === 200, 'PUT sauvegarde valide → 200');
  const back = (await api('GET', '/api/save', { token: alice.session })).json.save;
  ok(back.coins === 42 && back.selected === 'green' && back.bestTimes['1'] === 41230, 'GET renvoie ce qui a été sauvegardé');
  ok((await api('GET', '/api/save', { token: bob.session })).json.save === null, "Bob ne voit pas la sauvegarde d'Alice");

  // --- Usurpation d'identité ---
  const forgedBody = { ...good, coins: 999, userId: USERS.alice.id, uid: USERS.alice.id };
  await api('PUT', '/api/save', { token: bob.session, body: forgedBody });
  ok((await api('GET', '/api/save', { token: alice.session })).json.save.coins === 42, "Bob ne peut pas écraser Alice en envoyant son identifiant");
  const [payload, sig] = alice.session.split('.');
  const swapped = Buffer.from(JSON.stringify({ uid: USERS.bob.id, exp: Date.now() + 1e7 })).toString('base64url');
  ok((await api('GET', '/api/save', { token: `${swapped}.${sig}` })).status === 401, "jeton modifié (uid changé) → 401");
  ok((await api('GET', '/api/save', { token: `${payload}.${sig.slice(0, -2)}AA` })).status === 401, 'signature altérée → 401');
  const expired = createSession(USERS.alice.id, cfg.sessionSecret, -1000).token;
  ok((await api('GET', '/api/save', { token: expired })).status === 401, 'session expirée → 401');
  const wrongSecret = createSession(USERS.alice.id, 'un-autre-secret-123456', 60_000).token;
  ok((await api('GET', '/api/save', { token: wrongSecret })).status === 401, 'jeton signé avec un autre secret → 401');

  // --- Données falsifiées ---
  const put = (body: unknown) => api('PUT', '/api/save', { token: alice.session, body });
  ok((await put({ ...good, unlockedLevel: 5, bestTimes: {} })).status === 422, 'niveau 5 débloqué sans progression → 422');
  ok((await put({ ...good, bestTimes: { '1': 120 } })).status === 422, 'temps de 0,12 s → 422');
  ok((await put({ ...good, coins: 5_000_000 })).status === 422, 'millions de pièces → 422');
  ok((await put([1, 2, 3])).status === 422, 'tableau au lieu d\'un objet → 422');
  const dirty = (await put({ ...good, owned: ['beige', 'hacker'], selected: 'hacker', extra: '<script>' })).json.save;
  ok(dirty && !dirty.owned.includes('hacker') && dirty.selected === 'beige' && !('extra' in dirty), 'champs inconnus et personnages inventés nettoyés');
  ok((await api('PUT', '/api/save', { token: alice.session, raw: '{pas du json' })).status === 400, 'JSON invalide → 400');
  ok((await api('PUT', '/api/save', { token: alice.session, raw: JSON.stringify({ blob: 'x'.repeat(100_000) }) })).status === 413, 'corps de 100 Ko → 413');

  // --- Classement ---
  await api('PUT', '/api/save', { token: bob.session, body: { ...defaultSave(), unlockedLevel: 2, bestTimes: { '1': 35000 } } });
  await api('PUT', '/api/save', { token: alice.session, body: good });
  const lb = (await api('GET', '/api/leaderboard/1', { token: alice.session })).json;
  ok(lb.top.length === 2 && lb.top[0].name === 'bob' && lb.top[0].timeMs === 35000 && lb.top[1].name === 'Alice', 'classement trié par meilleur temps, avec les noms');
  ok(!JSON.stringify(lb).includes('2222'), "le classement n'expose aucun identifiant Discord");

  // --- Persistance sur disque ---
  await store.flush();
  const reopened = new JsonFileStore(dataFile);
  ok((await reopened.get(USERS.alice.id))?.save?.coins === 42, 'les données sont écrites sur disque et relues au redémarrage');

  // --- Suppression ---
  ok((await api('DELETE', '/api/save', { token: alice.session })).status === 200 && (await api('GET', '/api/save', { token: alice.session })).json.save === null, 'DELETE efface la sauvegarde');

  // --- Fichiers statiques ---
  const index = await fetch(base + '/');
  ok(index.status === 200 && (await index.text()).includes('jeu'), 'index.html servi');
  const traversal = await new Promise<{ status: number; body: string }>((resolve) => {
    http.get({ host: '127.0.0.1', port, path: '/..%2f..%2fsecret.txt' }, (r) => {
      let b = '';
      r.on('data', (c) => (b += c));
      r.on('end', () => resolve({ status: r.statusCode ?? 0, body: b }));
    });
  });
  ok(!traversal.body.includes('TOP-SECRET'), 'traversée de répertoire (../) bloquée');

  // --- Limitation de débit ---
  let limited = false;
  for (let i = 0; i < 30 && !limited; i++) limited = (await api('POST', '/api/token', { body: { code: 'bad' } })).status === 429;
  ok(limited, 'rafale de connexions → 429');

  server.close();
  fakeDiscord.close();
  console.log(failures === 0 ? '\nTOUS LES TESTS SERVEUR PASSENT' : `\n${failures} ÉCHEC(S)`);
  process.exit(failures ? 1 : 0);
})();
