import fs from 'node:fs';
import { LevelGrid } from '../src/systems/LevelGrid';
import { LEVELS } from '../src/levels';
import { ENEMIES } from '../src/data/enemies';
import { ENEMY_CHARS, DECOR_CHARS } from '../src/data/legend';
import { CHARACTERS } from '../src/data/characters';

const names = (f: string) => new Set([...fs.readFileSync(`${process.cwd()}/public/assets/atlases/spritesheet-${f}-default.xml`, 'utf8').matchAll(/name="([^"]+)"/g)].map((m) => m[1].replace(/\.png$/, '')));
const tiles = names('tiles'), enemies = names('enemies'), chars = names('characters');
let bad = 0;
const need = (set: Set<string>, n: string, why: string) => { if (!set.has(n)) { bad++; console.log('MANQUANT', n, '←', why); } };

for (const lv of LEVELS) {
  const g = new LevelGrid(lv.rows);
  console.log(`niveau ${lv.id} ${lv.name}: ${g.cols}x${g.rows}, rects solides=${g.mergeRects(g.isPhysicalSolid).length}`);
  for (let r = 0; r < g.rows; r++) for (let c = 0; c < g.cols; c++) {
    const ch = g.at(c, r);
    if (ch === '#') need(tiles, `terrain_${lv.theme.terrain}_${g.terrainPiece(c, r)}`, `L${lv.id} terrain ${c},${r}`);
    if (ch === '=') need(tiles, `terrain_${lv.theme.terrain}_${g.oneWayPiece(c, r)}`, `L${lv.id} plateforme`);
    if (ch === '~' || ch === 'v') need(tiles, g.liquidFrame(c, r), `L${lv.id} liquide`);
    if (DECOR_CHARS[ch]) need(tiles, DECOR_CHARS[ch], `L${lv.id} décor ${ch}`);
    if (ENEMY_CHARS[ch]) need(new Set(Object.keys(ENEMIES)), ENEMY_CHARS[ch], `L${lv.id} ennemi ${ch}`);
  }
  for (const k of ['background_clouds', `background_fade_${lv.theme.hills}`, `background_color_${lv.theme.hills}`])
    if (!fs.existsSync(`${process.cwd()}/public/assets/backgrounds/${k}.png`)) { bad++; console.log('FOND MANQUANT', k); }
  // chaque case '?' ,'B','D' etc. : pas de caractère inconnu
  const known = new Set(' #B?=~vcPDKS' + Object.keys(ENEMY_CHARS).join('') + Object.keys(DECOR_CHARS).join(''));
  for (const row of lv.rows) for (const ch of row) if (!known.has(ch)) { bad++; console.log('CARACTÈRE INCONNU', JSON.stringify(ch), 'L' + lv.id); }
}
for (const e of Object.values(ENEMIES)) for (const f of [...e.frames, ...(e.flat ? [e.flat] : [])]) need(enemies, f, `ennemi ${e.id}`);
for (const ch of CHARACTERS) for (const f of ['idle', 'walk_a', 'walk_b', 'jump', 'hit', 'duck', 'climb_a', 'climb_b']) need(chars, `character_${ch.color}_${f}`, 'personnage');
for (const f of ['coin_gold','coin_silver','star','spring','spring_out','flag_off','flag_green_a','flag_green_b','door_closed','door_closed_top','door_open','door_open_top','block_exclamation','block_empty','brick_brown','sign_left','sign_right','lock_red','hud_coin','hud_heart','hud_heart_empty','hud_character_multiply',...Array.from({length:10},(_,i)=>`hud_character_${i}`)] ) need(tiles, f, 'divers');
for (const t of ['grass','sand','snow','stone','purple']) for (const p of ['block_top','block_center','block_top_left','block_bottom_right','horizontal_left','horizontal_middle','horizontal_right']) need(tiles, `terrain_${t}_${p}`, 'panneaux/boutons');
console.log(bad === 0 ? '\nTOUT EST COHÉRENT : toutes les frames existent dans tes XML' : `\n${bad} problème(s)`);
process.exitCode = bad ? 1 : 0;
