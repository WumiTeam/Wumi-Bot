# Astro Run — Discord Activity (Étape 5 : Discord Activity)

Platformer 2D en **Phaser 3 + TypeScript + Vite**, entièrement construit avec le pack *New Platformer Pack 1.1* de Kenney (CC0).

## Lancer

```bash
npm install
npm run dev        # http://localhost:5173
```

Options d'URL pratiques pour tester :

| URL | Effet |
|---|---|
| `/?char=green` | force un personnage pour tester (sinon : celui choisi dans la boutique) |
| `/?level=3` | lance directement un niveau (1 à 5) |
| `/?debug` | affiche les hitboxes physiques |

## Commandes

| Action | Touches |
|---|---|
| Déplacement | `Q` / `D` ou `A` / `D` ou `←` / `→` |
| Saut | `Espace` (ou `↑`, `Z`, `W`) — maintenir = saut plus haut |
| Pause | `Échap` ou bouton **II** |
| Son coupé / activé | `M` |
| Menus | souris, tactile, ou `↑↓←→` + `Entrée` / `Espace` |

Commandes tactiles : affichées automatiquement sur appareil tactile (ou avec `/?touch` pour les tester).

## Progression et sauvegarde

- Menu principal : JOUER (niveau le plus avancé), NIVEAUX, PERSONNAGES, BOUTIQUE, PARAMÈTRES.
- 5 niveaux à difficulté croissante, débloqués un par un. Étoiles et meilleur temps par niveau.
- Les pièces ramassées rejoignent la bourse à la fin de la partie (victoire, game over, ou retour au menu).
- Personnages : Beige gratuit, les autres à acheter (prix dans `src/data/characters.ts`).
- Sauvegarde : `src/systems/SaveManager.ts`. Elle passe par une interface `SaveBackend` : aujourd'hui localStorage,
  à l'étape 5 un backend serveur (identifié par le joueur Discord authentifié) viendra la remplacer sans toucher au reste.

## Discord Activity

Guide complet : **`docs/DISCORD_SETUP.md`** (création de l'application, tunnel HTTPS, URL Mappings, mise en ligne).

- `npm run dev` lance le jeu (Vite, port 5173) **et** le serveur (Node, port 3001). `/api` est relayé automatiquement.
- Dans Discord : connexion automatique, sauvegarde sur le serveur liée au compte Discord vérifié, copie locale en secours.
- Navigateur normal : sauvegarde locale. `/?remote` (avec `ALLOW_DEV_LOGIN=true`) teste la sauvegarde serveur sans Discord.
- `npm test` : sauvegarde, serveur (faux Discord : usurpation, triche, persistance, limites) et cohérence des ressources.
- `npm run typecheck` : vérifie le client et le serveur.
- Production : `npm run build` puis `npm start` (le serveur sert aussi le jeu).
- Le serveur est compilé par esbuild (`scripts/`), sans dépendre de `tsx`.

## Structure

```
scripts/             compilation du serveur, serveur de dev, lanceur de tests
server/              serveur Node sans dépendance : sessions, Discord, stockage, validation
tests/               tests automatiques
docs/                guide Discord
public/assets/       atlas PNG + XML Kenney, fonds, sons OGG, licence
src/
  config.ts          constantes (physique, réglages du joueur, profondeurs)
  main.ts            création du jeu Phaser
  data/              personnages, ennemis, légende des niveaux
  levels/            niveaux (grilles ASCII) + registre
  systems/           Effects (particules), LevelGrid (logique pure), LevelBuilder, Controls, Audio, Animations, Parallax, Physics
  entities/          Player, Enemy
  scenes/            Boot, Menu, LevelSelect, Characters/Shop, Settings, Game
  net/               api, RemoteBackend (serveur + secours local), setup (choix du mode)
  discord/           intégration Embedded App SDK
  shared/            schéma de sauvegarde partagé client/serveur
  ui/                Hud, Panel, Button/ButtonMenu, Screens (pause, victoire, game over), TouchControls
```

## Ajouter un niveau

1. Créer `src/levels/level2.ts` (copier `level1.ts`) : une grille de caractères, 1 caractère = 1 tuile de 64 px.
2. L'ajouter au tableau `LEVELS` dans `src/levels/index.ts`.

Légende (voir `src/data/legend.ts`) : `#` terrain · `B` brique · `?` bloc à pièce · `=` plateforme traversable · `~` eau mortelle · `c` pièce · `P` départ · `D` porte de sortie · `K` point de sauvegarde · `S` ressort · `v` lave · `1`-`6`, `W` ennemis · `* ^ > E` décor.

## Ajouter un ennemi

Ajouter une entrée dans `src/data/enemies.ts` (frames de l'atlas, vitesse, hitbox) puis un caractère dans `ENEMY_CHARS`.

## Crédits

Graphismes et sons : Kenney (kenney.nl), licence CC0.
