import path from 'node:path';

/** Options esbuild communes : on regroupe le serveur en un seul fichier (imports sans extension gérés par esbuild). */
export const serverBuild = {
  entryPoints: ['server/index.ts'],
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node18',
  outfile: path.join('dist-server', 'index.mjs'),
  sourcemap: 'inline',
  logLevel: 'info',
};
