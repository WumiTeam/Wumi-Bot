// Exécute un fichier TypeScript (utilisé par « npm test ») : node scripts/run-ts.mjs tests/xxx.test.ts
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as esbuild from 'esbuild';

const file = process.argv[2];
if (!file) {
  console.error('Usage : node scripts/run-ts.mjs <fichier.ts>');
  process.exit(2);
}
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'astro-run-ts-'));
const out = path.join(dir, 'main.mjs');
try {
  await esbuild.build({ entryPoints: [file], bundle: true, platform: 'node', format: 'esm', target: 'node18', outfile: out, sourcemap: 'inline', logLevel: 'warning' });
  const r = spawnSync(process.execPath, ['--enable-source-maps', out], { stdio: 'inherit' });
  process.exitCode = r.status ?? 1;
} finally {
  fs.rmSync(dir, { recursive: true, force: true });
}
