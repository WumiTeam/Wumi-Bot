// Compile le serveur en dist-server/index.mjs (utilisé par « npm start »).
import * as esbuild from 'esbuild';
import { serverBuild } from './common.mjs';

await esbuild.build({ ...serverBuild, sourcemap: false, minify: false });
console.log('[build] serveur compilé : dist-server/index.mjs');
