// Serveur de développement : recompile et relance automatiquement à chaque modification.
import { spawn } from 'node:child_process';
import * as esbuild from 'esbuild';
import { serverBuild } from './common.mjs';

let child = null;

const stopChild = () =>
  new Promise((resolve) => {
    if (!child) return resolve();
    const c = child;
    child = null;
    c.once('exit', () => resolve());
    c.kill();
  });

async function restart() {
  await stopChild(); // on attend l'arrêt pour libérer le port avant de relancer
  child = spawn(process.execPath, ['--enable-source-maps', serverBuild.outfile], { stdio: 'inherit' });
}

const ctx = await esbuild.context({
  ...serverBuild,
  logLevel: 'warning',
  plugins: [
    {
      name: 'restart-server',
      setup(build) {
        build.onEnd((result) => {
          if (result.errors.length === 0) void restart();
        });
      },
    },
  ],
});
await ctx.watch();

const quit = async () => {
  await stopChild();
  await ctx.dispose();
  process.exit(0);
};
process.on('SIGINT', quit);
process.on('SIGTERM', quit);
