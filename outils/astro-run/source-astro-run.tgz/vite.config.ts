import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiPort = env.PORT || '3001';
  return {
    base: './',
    server: {
      host: true,
      port: 5173,
      // nécessaire pour exposer le serveur via un tunnel HTTPS (cloudflared / ngrok) pour Discord
      allowedHosts: true,
      // Avec un tunnel HTTPS (TUNNEL=1 dans .env), le rechargement à chaud doit passer par le port 443.
      hmr: env.TUNNEL === '1' ? { clientPort: 443 } : undefined,
      // En développement, Vite relaie /api vers notre serveur Node.
      proxy: { '/api': { target: `http://localhost:${apiPort}`, changeOrigin: true } },
    },
    build: { chunkSizeWarningLimit: 1500 },
  };
});
