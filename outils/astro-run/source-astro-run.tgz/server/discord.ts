import type { ServerConfig } from './config';

export interface DiscordUser {
  id: string;
  username: string;
  global_name?: string | null;
  avatar?: string | null;
}

export class DiscordError extends Error {
  constructor(
    message: string,
    public status = 502,
  ) {
    super(message);
  }
}

/** Échange le « code » d'autorisation de l'Activity contre un jeton d'accès. Le secret reste sur le serveur. */
export async function exchangeCode(cfg: ServerConfig, code: string): Promise<string> {
  if (!cfg.discordClientId || !cfg.discordClientSecret) throw new DiscordError('Discord n\'est pas configuré sur le serveur.', 503);
  const res = await fetch(`${cfg.discordApi}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: cfg.discordClientId,
      client_secret: cfg.discordClientSecret,
      grant_type: 'authorization_code',
      code,
    }),
  });
  if (!res.ok) throw new DiscordError('Code Discord refusé.', 401);
  const json = (await res.json()) as { access_token?: unknown };
  if (typeof json.access_token !== 'string' || !json.access_token) throw new DiscordError('Réponse Discord invalide.');
  return json.access_token;
}

/** Demande à Discord QUI est le joueur : c'est la seule source de l'identifiant utilisateur. */
export async function fetchUser(cfg: ServerConfig, accessToken: string): Promise<DiscordUser> {
  const res = await fetch(`${cfg.discordApi}/users/@me`, { headers: { Authorization: `Bearer ${accessToken}` } });
  if (!res.ok) throw new DiscordError('Impossible de vérifier le joueur auprès de Discord.', 401);
  const u = (await res.json()) as DiscordUser;
  if (typeof u.id !== 'string' || !/^\d{5,25}$/.test(u.id) || typeof u.username !== 'string') throw new DiscordError('Profil Discord invalide.');
  return u;
}
