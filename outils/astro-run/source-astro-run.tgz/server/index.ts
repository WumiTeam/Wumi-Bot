import { pathToFileURL } from 'node:url';
import { createApp } from './app';
import { loadConfig, loadDotEnv } from './config';
import { JsonFileStore } from './store';

loadDotEnv();

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const cfg = loadConfig();
  const store = new JsonFileStore(cfg.dataFile);
  const server = createApp(cfg, store);
  server.listen(cfg.port, () => {
    console.log(`[server] http://localhost:${cfg.port}  (${cfg.isProd ? 'production' : 'développement'})`);
    if (!cfg.discordClientId || !cfg.discordClientSecret) {
      console.warn('[server] Discord non configuré (DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET) : seul le mode navigateur fonctionne.');
    }
    if (cfg.allowDevLogin) console.warn('[server] ALLOW_DEV_LOGIN actif : connexion de test autorisée (jamais en production).');
  });
  const stop = () => void store.flush().then(() => process.exit(0));
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
