import crypto from 'node:crypto';

/**
 * Jeton de session signé (HMAC-SHA256), sans état côté serveur.
 * Le client ne peut ni le fabriquer ni le modifier : l'identifiant du joueur y est scellé par le serveur
 * au moment où il a vérifié le joueur auprès de Discord.
 */
export interface SessionPayload {
  uid: string;
  exp: number;
}

const b64 = (b: Buffer | string) => Buffer.from(b).toString('base64url');

function sign(data: string, secret: string): Buffer {
  return crypto.createHmac('sha256', secret).update(data).digest();
}

export function createSession(uid: string, secret: string, ttlMs: number, now = Date.now()): { token: string; expiresAt: number } {
  const payload: SessionPayload = { uid, exp: now + ttlMs };
  const body = b64(JSON.stringify(payload));
  return { token: `${body}.${b64(sign(body, secret))}`, expiresAt: payload.exp };
}

export function verifySession(token: string | undefined, secret: string, now = Date.now()): SessionPayload | null {
  if (!token || token.length > 1024) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  let given: Buffer;
  try {
    given = Buffer.from(sig, 'base64url');
  } catch {
    return null;
  }
  const expected = sign(body, secret);
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionPayload;
    if (typeof p.uid !== 'string' || typeof p.exp !== 'number' || p.exp <= now) return null;
    return p;
  } catch {
    return null;
  }
}
