import fs from 'node:fs';
import path from 'node:path';
import type { SaveData } from '../src/shared/saveSchema';

export interface UserRecord {
  save: SaveData | null;
  profile: { name: string };
  rev: number;
  updatedAt: number;
}

/**
 * Interface de stockage : aujourd'hui un fichier JSON, demain SQLite/Postgres/Redis sans toucher au reste du serveur.
 */
export interface Store {
  get(userId: string): Promise<UserRecord | null>;
  put(userId: string, rec: UserRecord): Promise<void>;
  delete(userId: string): Promise<void>;
  all(): Promise<[string, UserRecord][]>;
  flush(): Promise<void>;
}

export class JsonFileStore implements Store {
  private users = new Map<string, UserRecord>();
  private timer: NodeJS.Timeout | null = null;
  private writing: Promise<void> = Promise.resolve();

  constructor(private file: string) {
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8')) as { users?: Record<string, UserRecord> };
      for (const [id, rec] of Object.entries(raw.users ?? {})) this.users.set(id, rec);
    } catch {
      /* premier démarrage ou fichier absent */
    }
  }

  async get(userId: string): Promise<UserRecord | null> {
    return this.users.get(userId) ?? null;
  }

  async put(userId: string, rec: UserRecord): Promise<void> {
    this.users.set(userId, rec);
    this.schedule();
  }

  async delete(userId: string): Promise<void> {
    this.users.delete(userId);
    this.schedule();
  }

  async all(): Promise<[string, UserRecord][]> {
    return [...this.users.entries()];
  }

  private schedule(): void {
    if (this.timer) return;
    this.timer = setTimeout(() => void this.flush(), 250);
    this.timer.unref?.();
  }

  /** Écriture atomique (fichier temporaire puis renommage) : jamais de fichier à moitié écrit. */
  flush(): Promise<void> {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.writing = this.writing.then(async () => {
      const json = JSON.stringify({ users: Object.fromEntries(this.users) });
      await fs.promises.mkdir(path.dirname(this.file), { recursive: true });
      const tmp = `${this.file}.tmp`;
      await fs.promises.writeFile(tmp, json);
      await fs.promises.rename(tmp, this.file);
    });
    return this.writing.catch((e) => console.error('[store] écriture impossible', e));
  }
}
