/** Limiteur simple en mémoire : au plus `limit` requêtes par fenêtre et par clé. */
export class RateLimiter {
  private hits = new Map<string, { count: number; reset: number }>();

  constructor(
    private limit: number,
    private windowMs: number,
  ) {}

  allow(key: string, now = Date.now()): boolean {
    if (this.hits.size > 5000) for (const [k, v] of this.hits) if (v.reset <= now) this.hits.delete(k);
    const h = this.hits.get(key);
    if (!h || h.reset <= now) {
      this.hits.set(key, { count: 1, reset: now + this.windowMs });
      return true;
    }
    h.count++;
    return h.count <= this.limit;
  }
}
