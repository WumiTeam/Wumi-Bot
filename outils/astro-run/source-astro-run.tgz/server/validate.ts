import { MAX_LEVEL, sanitize, type SaveData } from '../src/shared/saveSchema';

const MAX_COINS = 1_000_000;
/** Aucun joueur ne finit un niveau en moins de 3 s : en dessous, la donnée est falsifiée. */
const MIN_PLAUSIBLE_TIME_MS = 3000;

export type Validation = { ok: true; data: SaveData } | { ok: false; reason: string };

/**
 * Le jeu tourne chez le joueur : on ne peut pas tout vérifier, mais on refuse tout ce qui est
 * structurellement impossible. La sauvegarde est reconstruite champ par champ (rien n'est copié tel quel).
 */
export function validateIncoming(raw: unknown): Validation {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ok: false, reason: 'format invalide' };
  const data = sanitize(raw);

  if (data.coins > MAX_COINS) return { ok: false, reason: 'trop de pièces' };

  let maxCompleted = 0;
  for (const [level, time] of Object.entries(data.bestTimes)) {
    const id = Number(level);
    if (!Number.isInteger(id) || id < 1 || id > MAX_LEVEL) return { ok: false, reason: 'niveau inconnu' };
    if (time < MIN_PLAUSIBLE_TIME_MS) return { ok: false, reason: 'temps impossible' };
    maxCompleted = Math.max(maxCompleted, id);
  }
  for (const [level, stars] of Object.entries(data.bestStars)) {
    const id = Number(level);
    if (!Number.isInteger(id) || id < 1 || id > MAX_LEVEL || stars < 0 || stars > 3) return { ok: false, reason: 'étoiles invalides' };
  }
  // On ne débloque un niveau qu'en terminant le précédent.
  if (data.unlockedLevel > Math.min(MAX_LEVEL, maxCompleted + 1)) return { ok: false, reason: 'niveau débloqué sans progression' };

  return { ok: true, data };
}
