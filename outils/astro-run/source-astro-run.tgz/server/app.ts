import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import type { ServerConfig } from './config';
import { DiscordError, exchangeCode, fetchUser } from './discord';
import { RateLimiter } from './rateLimit';
import { createSession, verifySession } from './session';
import type { Store } from './store';
import { validateIncoming } from './validate';

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ogg': 'audio/ogg',
  '.mp3': 'audio/mpeg',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json',
};

class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

/** Crée le serveur HTTP (API + fichiers du jeu). Aucune dépendance externe. */
export function createApp(cfg: ServerConfig, store: Store): http.Server {
  const authLimiter = new RateLimiter(20, 60_000); // par IP
  const apiLimiter = new RateLimiter(120, 60_000); // par joueur

  const clientIp = (req: http.IncomingMessage): string => {
    if (cfg.trustProxy) {
      const fwd = String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim();
      if (fwd) return fwd;
    }
    return req.socket.remoteAddress ?? 'unknown';
  };

  const sendJson = (res: http.ServerResponse, status: number, body: unknown) => {
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(JSON.stringify(body));
  };

  const readJson = (req: http.IncomingMessage, maxBytes = 64 * 1024): Promise<unknown> =>
    new Promise((resolve, reject) => {
      let size = 0;
      let tooBig = false;
      const chunks: Buffer[] = [];
      req.on('data', (c: Buffer) => {
        size += c.length;
        if (tooBig) {
          // On finit de lire (sans stocker) pour pouvoir répondre 413 proprement, mais pas au-delà de 1 Mo.
          if (size > 1024 * 1024) req.destroy();
          return;
        }
        if (size > maxBytes) {
          tooBig = true;
          chunks.length = 0;
          reject(new HttpError(413, 'Requête trop volumineuse'));
        } else chunks.push(c);
      });
      req.on('end', () => {
        if (tooBig) return;
        try {
          resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
        } catch {
          reject(new HttpError(400, 'JSON invalide'));
        }
      });
      req.on('error', reject);
    });

  /** L'identifiant du joueur vient UNIQUEMENT du jeton signé par ce serveur, jamais du corps de la requête. */
  const authenticate = (req: http.IncomingMessage): string => {
    const header = String(req.headers.authorization ?? '');
    const token = header.startsWith('Bearer ') ? header.slice(7) : undefined;
    const session = verifySession(token, cfg.sessionSecret);
    if (!session) throw new HttpError(401, 'Session invalide ou expirée');
    if (!apiLimiter.allow(session.uid)) throw new HttpError(429, 'Trop de requêtes');
    return session.uid;
  };

  const issue = async (userId: string, name: string) => {
    const existing = await store.get(userId);
    await store.put(userId, { save: existing?.save ?? null, profile: { name: name.slice(0, 40) }, rev: existing?.rev ?? 0, updatedAt: Date.now() });
    return createSession(userId, cfg.sessionSecret, cfg.sessionTtlMs);
  };

  async function handleApi(req: http.IncomingMessage, res: http.ServerResponse, url: URL): Promise<void> {
    const route = `${req.method} ${url.pathname}`;

    if (route === 'GET /api/health') return sendJson(res, 200, { ok: true, discordConfigured: !!(cfg.discordClientId && cfg.discordClientSecret) });

    if (route === 'POST /api/token') {
      if (!authLimiter.allow(clientIp(req))) throw new HttpError(429, 'Trop de tentatives');
      const body = (await readJson(req)) as { code?: unknown };
      if (typeof body.code !== 'string' || !body.code || body.code.length > 512) throw new HttpError(400, 'Code manquant');
      const accessToken = await exchangeCode(cfg, body.code);
      const user = await fetchUser(cfg, accessToken); // identité vérifiée par Discord
      const name = user.global_name || user.username;
      const { token, expiresAt } = await issue(user.id, name);
      // access_token : renvoyé au client uniquement pour sdk.commands.authenticate() ; on ne le stocke pas.
      return sendJson(res, 200, { access_token: accessToken, session: token, expiresAt, user: { name, avatar: user.avatar ?? null } });
    }

    if (route === 'POST /api/dev-login') {
      if (!cfg.allowDevLogin) throw new HttpError(404, 'Introuvable');
      if (!authLimiter.allow(clientIp(req))) throw new HttpError(429, 'Trop de tentatives');
      const { token, expiresAt } = await issue('999000000000000001', 'Testeur local');
      return sendJson(res, 200, { session: token, expiresAt, user: { name: 'Testeur local', avatar: null } });
    }

    if (url.pathname === '/api/save') {
      const uid = authenticate(req);
      if (req.method === 'GET') {
        const rec = await store.get(uid);
        return sendJson(res, 200, { save: rec?.save ?? null });
      }
      if (req.method === 'PUT') {
        const result = validateIncoming(await readJson(req));
        if (!result.ok) throw new HttpError(422, `Sauvegarde refusée : ${result.reason}`);
        const rec = await store.get(uid);
        await store.put(uid, { save: result.data, profile: rec?.profile ?? { name: 'Joueur' }, rev: (rec?.rev ?? 0) + 1, updatedAt: Date.now() });
        return sendJson(res, 200, { ok: true, save: result.data });
      }
      if (req.method === 'DELETE') {
        const rec = await store.get(uid);
        if (rec) await store.put(uid, { ...rec, save: null, rev: rec.rev + 1, updatedAt: Date.now() });
        return sendJson(res, 200, { ok: true });
      }
    }

    // Classement par niveau (base pour les futurs modes multijoueur)
    const lb = url.pathname.match(/^\/api\/leaderboard\/(\d{1,3})$/);
    if (req.method === 'GET' && lb) {
      authenticate(req);
      const level = lb[1];
      const rows: { name: string; timeMs: number }[] = [];
      for (const [, rec] of await store.all()) {
        const t = rec.save?.bestTimes?.[level];
        if (typeof t === 'number') rows.push({ name: rec.profile.name, timeMs: t });
      }
      rows.sort((a, b) => a.timeMs - b.timeMs);
      return sendJson(res, 200, { level: Number(level), top: rows.slice(0, 10) });
    }

    throw new HttpError(404, 'Introuvable');
  }

  function serveStatic(req: http.IncomingMessage, res: http.ServerResponse, url: URL): void {
    if (req.method !== 'GET' && req.method !== 'HEAD') return void sendJson(res, 405, { error: 'Méthode non autorisée' });
    let rel: string;
    try {
      rel = decodeURIComponent(url.pathname);
    } catch {
      return void sendJson(res, 400, { error: 'URL invalide' });
    }
    // Protection contre « ../../ » : le chemin final doit rester dans dist/
    let file = path.resolve(cfg.distDir, '.' + path.posix.normalize('/' + rel));
    if (!file.startsWith(cfg.distDir + path.sep) && file !== cfg.distDir) return void sendJson(res, 403, { error: 'Interdit' });
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return void res.end('Introuvable (as-tu lancé « npm run build » ?)');
    }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] ?? 'application/octet-stream',
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
    });
    if (req.method === 'HEAD') return void res.end();
    fs.createReadStream(file).pipe(res);
  }

  return http.createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      handleApi(req, res, url).catch((err) => {
        if (err instanceof HttpError || err instanceof DiscordError) {
          const status = err instanceof HttpError ? err.status : err.status;
          return sendJson(res, status, { error: err.message });
        }
        console.error('[api] erreur', err);
        sendJson(res, 500, { error: 'Erreur interne' });
      });
    } else {
      serveStatic(req, res, url);
    }
  });
}
