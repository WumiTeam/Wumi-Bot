import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

/** Lit un fichier .env (KEY=VALUE) sans écraser les variables déjà définies. */
export function loadDotEnv(file = path.resolve(process.cwd(), '.env')): void {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const value = m[2].replace(/^(['"])(.*)\1$/, '$2');
    if (process.env[m[1]] === undefined) process.env[m[1]] = value;
  }
}

export interface ServerConfig {
  port: number;
  isProd: boolean;
  sessionSecret: string;
  discordClientId?: string;
  discordClientSecret?: string;
  discordApi: string;
  dataFile: string;
  distDir: string;
  allowDevLogin: boolean;
  trustProxy: boolean;
  sessionTtlMs: number;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): ServerConfig {
  const isProd = env.NODE_ENV === 'production';
  let sessionSecret = env.SESSION_SECRET;
  if (!sessionSecret || sessionSecret.length < 16) {
    if (isProd) throw new Error('SESSION_SECRET (16 caractères minimum) est obligatoire en production.');
    sessionSecret = crypto.randomBytes(32).toString('hex');
    console.warn('[config] SESSION_SECRET absent : secret temporaire généré (les sessions sautent à chaque redémarrage).');
  }
  return {
    port: Number(env.PORT ?? 3001),
    isProd,
    sessionSecret,
    discordClientId: env.DISCORD_CLIENT_ID || env.VITE_DISCORD_CLIENT_ID || undefined,
    discordClientSecret: env.DISCORD_CLIENT_SECRET || undefined,
    discordApi: (env.DISCORD_API_BASE ?? 'https://discord.com/api').replace(/\/$/, ''),
    dataFile: path.resolve(env.DATA_FILE ?? 'data/saves.json'),
    distDir: path.resolve(env.DIST_DIR ?? 'dist'),
    allowDevLogin: env.ALLOW_DEV_LOGIN === 'true' && !isProd,
    trustProxy: env.TRUST_PROXY === 'true',
    sessionTtlMs: Number(env.SESSION_TTL_HOURS ?? 12) * 3600_000,
  };
}
