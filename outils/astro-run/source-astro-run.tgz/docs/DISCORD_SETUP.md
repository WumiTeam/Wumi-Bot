# Lancer le jeu comme Discord Activity — guide pas à pas

L'interface du portail Discord évolue parfois : les noms ci-dessous peuvent légèrement varier, mais les étapes restent les mêmes.

## 1. Créer l'application Discord

1. Va sur https://discord.com/developers/applications puis **New Application** (donne-lui le nom du jeu).
2. **General Information** : copie l'**Application ID**. C'est ton *Client ID*.
3. **OAuth2** : clique **Reset Secret**, copie le **Client Secret** (affiché une seule fois).
   Ajoute aussi, dans **Redirects**, l'adresse `https://127.0.0.1` (le SDK en a besoin pour l'autorisation).
4. **Activities** (menu de gauche) : active **Enable Activities**. Coche les plateformes voulues (ordinateur, mobile).

## 2. Configurer le projet

```bash
cp .env.example .env        # puis ouvre .env
```

Remplis :

| Variable | Valeur |
|---|---|
| `VITE_DISCORD_CLIENT_ID` | l'Application ID (étape 1.2) |
| `DISCORD_CLIENT_SECRET` | le Client Secret (étape 1.3). **Jamais** dans le code, jamais dans un dépôt public. |
| `SESSION_SECRET` | une longue chaîne aléatoire : `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `TUNNEL` | `1` quand tu testes via un tunnel HTTPS |

```bash
npm install
npm run dev     # lance le jeu (port 5173) ET le serveur de sauvegarde (port 3001)
```

## 3. Exposer ton PC en HTTPS (test)

Discord exige une adresse HTTPS publique. Le plus simple : **cloudflared** (gratuit, sans compte pour un test).

```bash
cloudflared tunnel --url http://localhost:5173
```

Il affiche une adresse du type `https://mots-au-hasard.trycloudflare.com`. Cette adresse **change à chaque lancement**.

## 4. Dire à Discord où se trouve le jeu

Portail > ton application > **Activities > URL Mappings** :

| Prefix | Target |
|---|---|
| `/` | `mots-au-hasard.trycloudflare.com` (sans `https://`) |

Enregistre. À chaque nouveau tunnel, mets à jour cette ligne.

## 5. Lancer dans Discord

1. Discord > **Paramètres > Avancés > Mode développeur** : activé.
2. Rejoins un salon vocal d'un serveur de test (tu dois être membre de l'équipe de l'application, ce qui est le cas si tu l'as créée).
3. Clique l'icône **Activités** (la fusée) : ton application apparaît. Lance-la.

Le jeu doit afficher **« Connecté : ton nom »** en haut à gauche du menu. Ta progression est alors liée à ton compte Discord.
Si tu vois **« Hors ligne : progression locale »**, la connexion a échoué : ouvre la console (Discord ordinateur : `Ctrl+Shift+I`) et lis le message `[net]`.

## 6. Mise en ligne (production)

1. `npm run build` crée le jeu (`dist/`) et compile le serveur (`dist-server/index.mjs`).
2. Héberge sur un service Node (Render, Railway, Fly.io, un VPS…) : commande de build `npm install && npm run build`, commande de démarrage `npm start`.
3. Variables d'environnement de l'hébergeur : `NODE_ENV=production`, `TRUST_PROXY=true`, `VITE_DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `SESSION_SECRET`, `DATA_FILE`.
   `VITE_DISCORD_CLIENT_ID` doit être définie **avant** `npm run build` (elle est intégrée au jeu à la compilation).
4. Monte un **disque persistant** pour `DATA_FILE` (sinon les sauvegardes disparaissent à chaque redéploiement).
5. Dans URL Mappings, remplace l'adresse du tunnel par le domaine de l'hébergeur.
6. Pour que d'autres personnes puissent lancer l'Activity, il faut la publier via le portail (Discord vérifie l'application selon sa taille).

## Dépannage

| Symptôme | Cause probable |
|---|---|
| Écran noir dans Discord | URL Mapping absent ou tunnel arrêté / changé |
| « Hors ligne » + `VITE_DISCORD_CLIENT_ID est absent` | variable manquante : redémarre `npm run dev` après avoir modifié `.env` |
| « Hors ligne » + `HTTP 401` à l'échange du code | mauvais Client Secret, ou mauvais Client ID |
| « Hors ligne » + `HTTP 503` | `DISCORD_CLIENT_SECRET` absent côté serveur |
| `/?remote` refusé en navigateur | ajoute `ALLOW_DEV_LOGIN=true` dans `.env` (jamais en production) |

## Sécurité : ce qui est en place

- Le serveur reçoit un *code* temporaire, l'échange avec le Client Secret (qui ne quitte jamais le serveur) et **demande à Discord qui est le joueur**.
  L'identifiant n'est jamais lu dans une requête du client.
- Le serveur renvoie un jeton de session signé (HMAC-SHA256, 12 h). Impossible à fabriquer ou à modifier sans `SESSION_SECRET`.
- Chaque sauvegarde reçue est reconstruite champ par champ et refusée si elle est impossible (temps trop court, niveau débloqué sans progression, pièces absurdes).
- Limitation de débit, taille des requêtes bornée, protection contre l'accès aux fichiers hors de `dist/`.
- Limite assumée : le jeu tourne chez le joueur, donc un joueur déterminé peut tricher à l'intérieur des limites plausibles. Les pièces sont une monnaie virtuelle sans valeur réelle.

## Préparer le multijoueur

- `GET /api/leaderboard/:niveau` renvoie déjà le top 10 des meilleurs temps (noms affichés, jamais les identifiants).
- `connection.context` (voir `src/net/setup.ts`) contient `instanceId`, `channelId` et `guildId` : `instanceId` identifie la partie de salon vocal en cours, c'est la clé naturelle d'une « salle » pour une future course entre joueurs (WebSocket via `/.proxy/`).
