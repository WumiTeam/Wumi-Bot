import { connectDiscord, isDiscordActivity, type ActivityContext } from '../discord/discord';
import { saveManager, LocalBackend } from '../systems/SaveManager';
import { apiUrl, configureApi } from './api';
import { RemoteBackend, ResilientBackend } from './RemoteBackend';

export type Connection =
  | { mode: 'discord'; name: string; context: ActivityContext }
  | { mode: 'dev'; name: string }
  | { mode: 'local' }
  | { mode: 'offline'; reason: string };

let connection: Connection = { mode: 'local' };
export const getConnection = (): Connection => connection;

/**
 * Choisit où sauvegarder AVANT que la sauvegarde soit lue :
 *  - dans Discord       → serveur (identité vérifiée par Discord), copie locale en secours ;
 *  - navigateur + ?remote → serveur via la connexion de test (ALLOW_DEV_LOGIN=true côté serveur) ;
 *  - navigateur normal  → localStorage uniquement.
 */
export async function setupBackend(): Promise<Connection> {
  const cache = new LocalBackend('astro-run:cache:v1');
  try {
    if (isDiscordActivity()) {
      const d = await connectDiscord();
      // Wumi : l'API du jeu vit sous /astro/api ; le serveur et le salon disent
      // a Wumi ou annoncer les records et a quel classement les inscrire.
      configureApi({
        base: '/astro',
        token: d.session,
        refresh: d.refresh,
        headers: { 'X-Wumi-Guild': d.context.guildId ?? '', 'X-Wumi-Channel': d.context.channelId ?? '' },
      });
      saveManager.setBackend(new ResilientBackend(new RemoteBackend(), cache));
      connection = { mode: 'discord', name: d.user.name, context: d.context };
    } else if (new URLSearchParams(window.location.search).has('remote')) {
      const res = await fetch(apiUrl('/api/dev-login'), { method: 'POST' });
      if (!res.ok) throw new Error(`dev-login refusé (HTTP ${res.status}) : ALLOW_DEV_LOGIN=true dans .env ?`);
      const j = (await res.json()) as { session: string; user: { name: string } };
      configureApi({ base: '', token: j.session });
      saveManager.setBackend(new ResilientBackend(new RemoteBackend(), cache));
      connection = { mode: 'dev', name: j.user.name };
    }
  } catch (e) {
    console.error('[net] connexion impossible, progression locale uniquement', e);
    connection = { mode: 'offline', reason: e instanceof Error ? e.message : String(e) };
  }
  return connection;
}
