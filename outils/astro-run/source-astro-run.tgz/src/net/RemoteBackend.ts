import { sanitize, type SaveData } from '../shared/saveSchema';
import type { SaveBackend } from '../systems/SaveManager';
import { apiFetch } from './api';

/** Sauvegarde sur notre serveur. Le serveur sait qui est le joueur grâce à la session, jamais grâce à un identifiant envoyé ici. */
export class RemoteBackend implements SaveBackend {
  async load(): Promise<unknown | null> {
    const res = await apiFetch('/api/save');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return ((await res.json()) as { save: unknown | null }).save;
  }

  async save(data: SaveData): Promise<void> {
    // keepalive : l'envoi continue même si la fenêtre se ferme (fermeture de l'Activity)
    const res = await apiFetch('/api/save', { method: 'PUT', body: JSON.stringify(data), keepalive: true });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  }

  async clear(): Promise<void> {
    const res = await apiFetch('/api/save', { method: 'DELETE' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  }
}

/**
 * Serveur d'abord, copie locale en secours : si le serveur est injoignable, le joueur continue
 * à jouer et sa progression reste sauvegardée localement.
 */
export class ResilientBackend implements SaveBackend {
  constructor(
    private primary: SaveBackend,
    private fallback: SaveBackend,
  ) {}

  async load(): Promise<unknown | null> {
    try {
      const data = await this.primary.load();
      if (data) await this.fallback.save(sanitize(data)); // copie locale à jour
      return data;
    } catch (e) {
      console.warn('[save] serveur injoignable, lecture de la copie locale', e);
      return this.fallback.load();
    }
  }

  async save(data: SaveData): Promise<void> {
    await this.fallback.save(data);
    try {
      await this.primary.save(data);
    } catch (e) {
      console.warn('[save] envoi au serveur impossible (copie locale conservée)', e);
    }
  }

  async clear(): Promise<void> {
    await this.fallback.clear();
    await this.primary.clear().catch((e) => console.warn('[save] effacement serveur impossible', e));
  }
}
