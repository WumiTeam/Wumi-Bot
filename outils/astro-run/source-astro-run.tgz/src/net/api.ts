/**
 * Appels HTTP vers notre serveur. Dans une Activity Discord, toute requête doit passer par le proxy
 * « /.proxy » (règle de sécurité de Discord) ; en navigateur normal, on appelle directement /api.
 */
let base = '';
let token: string | null = null;
let refresh: (() => Promise<string>) | null = null;
let extra: Record<string, string> = {};

export function configureApi(o: { base: string; token: string; refresh?: () => Promise<string>; headers?: Record<string, string> }): void {
  base = o.base;
  token = o.token;
  refresh = o.refresh ?? null;
  extra = o.headers ?? {};
}

export function apiUrl(path: string): string {
  return base + path;
}

/** Appel authentifié. Si la session a expiré (401), on en redemande une et on rejoue l'appel une fois. */
export async function apiFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const run = () =>
    fetch(base + path, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...extra, ...(init.headers ?? {}), Authorization: `Bearer ${token ?? ''}` },
    });
  let res = await run();
  if (res.status === 401 && refresh) {
    token = await refresh();
    res = await run();
  }
  return res;
}
