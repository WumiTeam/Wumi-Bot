import { CHARACTERS } from '../data/characters';
import { LEVELS } from '../levels';

/** Plus grand identifiant de niveau existant. */
export const MAX_LEVEL = Math.max(...LEVELS.map((l) => l.id));

/** Tout ce qui est sauvegardé pour un joueur. */
export interface SaveData {
  version: 1;
  coins: number;
  owned: string[];
  selected: string;
  /** Plus grand niveau accessible. */
  unlockedLevel: number;
  /** Meilleur temps (ms) par niveau. */
  bestTimes: Record<string, number>;
  /** Meilleur nombre d'étoiles par niveau. */
  bestStars: Record<string, number>;
  settings: { muted: boolean; volume: number };
}

export function defaultSave(): SaveData {
  return {
    version: 1,
    coins: 0,
    owned: [CHARACTERS[0].id],
    selected: CHARACTERS[0].id,
    unlockedLevel: 1,
    bestTimes: {},
    bestStars: {},
    settings: { muted: false, volume: 0.8 },
  };
}

const num = (v: unknown, fallback: number, min = 0): number => (typeof v === 'number' && Number.isFinite(v) ? Math.max(min, v) : fallback);

/** Valide et complète des données lues (anciennes versions, données corrompues ou modifiées à la main). */
export function sanitize(raw: unknown): SaveData {
  const d = defaultSave();
  if (!raw || typeof raw !== 'object') return d;
  const r = raw as Record<string, any>;

  d.coins = Math.floor(num(r.coins, 0));
  const known = new Set(CHARACTERS.map((c) => c.id));
  const owned = Array.isArray(r.owned) ? r.owned.filter((id: unknown) => typeof id === 'string' && known.has(id)) : [];
  d.owned = [...new Set([CHARACTERS[0].id, ...owned])];
  d.selected = typeof r.selected === 'string' && d.owned.includes(r.selected) ? r.selected : CHARACTERS[0].id;

  d.unlockedLevel = Math.min(MAX_LEVEL, Math.max(1, Math.floor(num(r.unlockedLevel, 1, 1))));

  for (const [field, target] of [['bestTimes', d.bestTimes], ['bestStars', d.bestStars]] as const) {
    if (r[field] && typeof r[field] === 'object') {
      for (const [k, v] of Object.entries(r[field])) if (typeof v === 'number' && Number.isFinite(v) && v > 0) target[k] = v;
    }
  }
  if (r.settings && typeof r.settings === 'object') {
    d.settings.muted = r.settings.muted === true;
    d.settings.volume = Math.min(1, num(r.settings.volume, 0.8));
  }
  return d;
}

