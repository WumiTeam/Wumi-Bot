import Phaser from 'phaser';
import { GAME_H, GAME_W, PHYSICS } from './config';
import { BootScene } from './scenes/BootScene';
import { CharactersScene, ShopScene } from './scenes/CharacterCardsScene';
import { GameScene } from './scenes/GameScene';
import { LevelSelectScene } from './scenes/LevelSelectScene';
import { MenuScene } from './scenes/MenuScene';
import { SettingsScene } from './scenes/SettingsScene';

// ?debug dans l'URL affiche les hitboxes Arcade.
const debug = new URLSearchParams(window.location.search).has('debug');

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: GAME_W,
  height: GAME_H,
  backgroundColor: '#c4e3ff',
  roundPixels: true,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  physics: {
    default: 'arcade',
    arcade: { gravity: { x: 0, y: PHYSICS.gravity }, debug },
  },
  scene: [BootScene, MenuScene, LevelSelectScene, CharactersScene, ShopScene, SettingsScene, GameScene],
});
