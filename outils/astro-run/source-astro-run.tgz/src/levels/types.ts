export interface LevelTheme {
  /** Jeu de tuiles de terrain : terrain_<terrain>_* dans l'atlas des tuiles. */
  terrain: 'grass' | 'dirt' | 'sand' | 'snow' | 'stone' | 'purple';
  /** Fonds en parallaxe : background_fade_<hills> / background_color_<hills>. */
  hills: 'hills' | 'desert' | 'trees' | 'mushrooms';
}

export interface LevelDef {
  id: number;
  name: string;
  theme: LevelTheme;
  /** Grille ASCII, voir data/legend.ts. */
  rows: string[];
}
