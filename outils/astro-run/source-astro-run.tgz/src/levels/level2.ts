import type { LevelDef } from './types';

/** Niveau 2 — « Dunes brûlantes ». Légende : src/data/legend.ts */
export const level2: LevelDef = {
  id: 2,
  name: 'Dunes brûlantes',
  theme: { terrain: 'sand', hills: 'desert' },
  rows: [
    '                                                                                                                                                      ',
    '                                                                                                                                                      ',
    '                                                                                                                                                      ',
    '                                                               cccccc                                                                                 ',
    '                                                               ======           3                                                                     ',
    '                                                                                          3                     cc                                    ',
    '                          B?B?B         cc        C                                 B?B             cc          ##                                    ',
    '                  ccc                            ####                                                         ####                                    ',
    '  P  C  ccc  C6         C     r  W ccc  ==  K  ########   5 CS      ==    6 C     1   ccc    Wr 5   ==   KC ######  C 2 r 6 ccc   ==   C 1      E D   ',
    '##################   ##################    ########################    ############################    ##########################    #################',
    '##################vvv##################vvvv########################vvvv############################vvvv##########################vvvv#################',
    '##################vvv##################vvvv########################vvvv############################vvvv##########################vvvv#################',
  ],
};
