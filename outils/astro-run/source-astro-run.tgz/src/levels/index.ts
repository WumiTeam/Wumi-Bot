import type { LevelDef } from './types';
import { level1 } from './level1';
import { level2 } from './level2';
import { level3 } from './level3';
import { level4 } from './level4';
import { level5 } from './level5';

/** Registre des niveaux : pour en ajouter un, créer levelN.ts et l'ajouter ici (ordre = ordre de progression). */
export const LEVELS: LevelDef[] = [level1, level2, level3, level4, level5];

export function getLevel(id: number): LevelDef {
  return LEVELS.find((l) => l.id === id) ?? LEVELS[0];
}
