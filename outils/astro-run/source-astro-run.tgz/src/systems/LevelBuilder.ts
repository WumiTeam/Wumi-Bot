import Phaser from 'phaser';
import { DEPTH, TILE } from '../config';
import { DECOR_CHARS, ENEMY_CHARS, L } from '../data/legend';
import type { LevelDef } from '../levels/types';
import { LevelGrid, type CellRect } from './LevelGrid';

export interface CoinEntry {
  img: Phaser.GameObjects.Image;
  baseY: number;
  phase: number;
  got: boolean;
}

export interface EnemySpawn {
  id: string;
  x: number;
  footY: number;
}

export interface CheckpointEntry {
  zone: Phaser.GameObjects.Zone;
  sprite: Phaser.GameObjects.Sprite;
  x: number;
  footY: number;
  active: boolean;
}

export interface LevelRuntime {
  grid: LevelGrid;
  widthPx: number;
  heightPx: number;
  start: { x: number; footY: number };
  solids: Phaser.Physics.Arcade.StaticGroup;
  oneWays: Phaser.Physics.Arcade.StaticGroup;
  water: Phaser.Physics.Arcade.StaticGroup;
  blocks: Phaser.Physics.Arcade.StaticGroup;
  springs: Phaser.Physics.Arcade.StaticGroup;
  checkpoints: Phaser.Physics.Arcade.StaticGroup;
  doorZone: Phaser.Physics.Arcade.StaticGroup;
  coins: CoinEntry[];
  enemySpawns: EnemySpawn[];
  openDoor(): void;
  isGroundAt(px: number, py: number): boolean;
}

/** Zone invisible avec corps statique, ajoutée à un groupe (origine en haut à gauche). */
function addZone(
  scene: Phaser.Scene,
  group: Phaser.Physics.Arcade.StaticGroup,
  x: number,
  y: number,
  w: number,
  h: number,
): Phaser.GameObjects.Zone {
  const zone = scene.add.zone(x, y, w, h).setOrigin(0, 0);
  scene.physics.add.existing(zone, true);
  group.add(zone);
  return zone;
}

function rectToPx(r: CellRect) {
  return { x: r.c0 * TILE, y: r.r0 * TILE, w: (r.c1 - r.c0 + 1) * TILE, h: r.h * TILE };
}

/** Construit tout le niveau (visuels + physique) à partir de la grille ASCII. */
export function buildLevel(scene: Phaser.Scene, def: LevelDef): LevelRuntime {
  const grid = new LevelGrid(def.rows);
  const tiles = scene.textures.get('tiles');
  const frameOr = (name: string, fallback: string) => (tiles.has(name) ? name : fallback);
  const terrain = (piece: string) => frameOr(`terrain_${def.theme.terrain}_${piece}`, `terrain_${def.theme.terrain}_block_center`);
  const widthPx = grid.cols * TILE;
  const heightPx = grid.rows * TILE;

  const solids = scene.physics.add.staticGroup();
  const oneWays = scene.physics.add.staticGroup();
  const water = scene.physics.add.staticGroup();
  const blocks = scene.physics.add.staticGroup();
  const springs = scene.physics.add.staticGroup();
  const checkpoints = scene.physics.add.staticGroup();
  const doorZone = scene.physics.add.staticGroup();

  // --- Décor (derrière le terrain) ------------------------------------------------------
  for (const d of grid.find(Object.keys(DECOR_CHARS).join(''))) {
    scene.add
      .image(d.c * TILE, d.r * TILE, 'tiles', DECOR_CHARS[d.ch])
      .setOrigin(0, 0)
      .setDepth(DEPTH.decor);
  }

  // --- Terrain visuel (auto-tuilé) + briques ---------------------------------------------
  for (let r = 0; r < grid.rows; r++) {
    for (let c = 0; c < grid.cols; c++) {
      const ch = grid.at(c, r);
      let frame: string | null = null;
      if (ch === L.SOLID) frame = terrain(grid.terrainPiece(c, r));
      else if (ch === L.BRICK) frame = 'brick_brown';
      else if (ch === L.ONE_WAY) frame = terrain(grid.oneWayPiece(c, r));
      else if (ch === L.WATER || ch === L.LAVA) frame = grid.liquidFrame(c, r);
      if (frame) {
        scene.add
          .image(c * TILE, r * TILE, 'tiles', frame)
          .setOrigin(0, 0)
          .setDepth(ch === L.WATER || ch === L.LAVA ? DEPTH.water : DEPTH.terrain);
      }
    }
  }

  // --- Collisions : rectangles fusionnés ------------------------------------------------
  for (const rect of grid.mergeRects(grid.isPhysicalSolid)) {
    const p = rectToPx(rect);
    addZone(scene, solids, p.x, p.y, p.w, p.h);
  }
  // plateformes traversables : corps fin placé sur le dessus
  for (const rect of grid.mergeRowRuns((c, r) => grid.at(c, r) === L.ONE_WAY)) {
    const p = rectToPx(rect);
    addZone(scene, oneWays, p.x, p.y, p.w, 40);
  }
  // eau et lave mortelles (on ne déclenche qu'à partir de 20 px sous la surface)
  for (const rect of grid.mergeRects(grid.isLiquid)) {
    const p = rectToPx(rect);
    addZone(scene, water, p.x, p.y + 20, p.w, p.h - 20);
  }

  // --- Blocs « ! » ----------------------------------------------------------------------
  for (const b of grid.find(L.QUESTION)) {
    const block = blocks.create(b.c * TILE + TILE / 2, b.r * TILE + TILE / 2, 'tiles', 'block_exclamation');
    block.setDepth(DEPTH.terrain);
    block.setData('used', false);
  }

  // --- Ressorts -------------------------------------------------------------------------
  for (const s of grid.find(L.SPRING)) {
    const img = scene.add.image(s.c * TILE, s.r * TILE, 'tiles', 'spring').setOrigin(0, 0).setDepth(DEPTH.decor + 1);
    const zone = addZone(scene, springs, s.c * TILE + 8, s.r * TILE + 22, TILE - 16, 30);
    zone.setData('sprite', img);
  }

  // --- Points de sauvegarde -------------------------------------------------------------
  for (const k of grid.find(L.CHECKPOINT)) {
    const sprite = scene.add.sprite(k.c * TILE, k.r * TILE, 'tiles', 'flag_off').setOrigin(0, 0).setDepth(DEPTH.decor + 1);
    const zone = addZone(scene, checkpoints, k.c * TILE + 8, k.r * TILE, TILE - 16, TILE);
    zone.setData('entry', {
      zone,
      sprite,
      x: k.c * TILE + TILE / 2,
      footY: (k.r + 1) * TILE,
      active: false,
    } as CheckpointEntry);
  }

  // --- Porte de sortie (2 tuiles de haut) ------------------------------------------------
  let doorBottom: Phaser.GameObjects.Image | null = null;
  let doorTop: Phaser.GameObjects.Image | null = null;
  const door = grid.find(L.DOOR)[0];
  if (door) {
    doorBottom = scene.add.image(door.c * TILE, door.r * TILE, 'tiles', 'door_closed').setOrigin(0, 0).setDepth(DEPTH.door);
    doorTop = scene.add.image(door.c * TILE, (door.r - 1) * TILE, 'tiles', 'door_closed_top').setOrigin(0, 0).setDepth(DEPTH.door);
    addZone(scene, doorZone, door.c * TILE + 10, (door.r - 1) * TILE + 16, TILE - 20, TILE * 2 - 16);
  }

  // --- Pièces ---------------------------------------------------------------------------
  const coins: CoinEntry[] = grid.find(L.COIN).map((c, i) => {
    const x = c.c * TILE + TILE / 2;
    const y = c.r * TILE + TILE / 2;
    const img = scene.add.image(x, y, 'tiles', 'coin_gold').setDepth(DEPTH.coin);
    return { img, baseY: y, phase: i * 0.7, got: false };
  });

  // --- Ennemis (instanciés par la scène) -------------------------------------------------
  const enemySpawns: EnemySpawn[] = grid.find(Object.keys(ENEMY_CHARS).join('')).map((e) => ({
    id: ENEMY_CHARS[e.ch],
    x: e.c * TILE + TILE / 2,
    footY: (e.r + 1) * TILE,
  }));

  const p = grid.find(L.PLAYER)[0] ?? { c: 1, r: grid.rows - 3 };

  return {
    grid,
    widthPx,
    heightPx,
    start: { x: p.c * TILE + TILE / 2, footY: (p.r + 1) * TILE },
    solids,
    oneWays,
    water,
    blocks,
    springs,
    checkpoints,
    doorZone,
    coins,
    enemySpawns,
    openDoor() {
      doorBottom?.setFrame('door_open');
      doorTop?.setFrame('door_open_top');
    },
    isGroundAt(px: number, py: number) {
      return grid.isGroundCell(Math.floor(px / TILE), Math.floor(py / TILE));
    },
  };
}
