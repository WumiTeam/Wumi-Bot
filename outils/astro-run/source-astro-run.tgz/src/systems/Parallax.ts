import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_W } from '../config';

/**
 * Fond à 3 couches empilées (nuages → collines pâles → collines colorées), chacune
 * défilant à sa vitesse. Les tuiles de fond de Kenney (256 px) sont conçues pour s'empiler ainsi.
 */
export class Parallax {
  private layers: { sprite: Phaser.GameObjects.TileSprite; factor: number; drift: number }[] = [];

  constructor(scene: Phaser.Scene, hills: string) {
    const tile = 256;
    scene.cameras.main.setBackgroundColor('#c4e3ff');
    const defs = [
      { key: 'bg_clouds', y: GAME_H - tile * 3, factor: 0.06, drift: 0.012 },
      { key: `bg_fade_${hills}`, y: GAME_H - tile * 2, factor: 0.16, drift: 0 },
      { key: `bg_color_${hills}`, y: GAME_H - tile, factor: 0.3, drift: 0 },
    ];
    defs.forEach((d, i) => {
      const sprite = scene.add
        .tileSprite(0, d.y, GAME_W, tile, d.key)
        .setOrigin(0, 0)
        .setScrollFactor(0)
        .setDepth(DEPTH.background + i);
      this.layers.push({ sprite, factor: d.factor, drift: d.drift });
    });
  }

  update(cameraX: number, timeMs: number): void {
    for (const l of this.layers) {
      l.sprite.tilePositionX = cameraX * l.factor + timeMs * l.drift;
    }
  }
}
