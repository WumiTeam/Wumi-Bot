import Phaser from 'phaser';
import { CHARACTERS } from '../data/characters';
import { ENEMIES } from '../data/enemies';

/** Crée toutes les animations à partir des frames des atlas XML. */
export function createAnimations(scene: Phaser.Scene): void {
  const anims = scene.anims;

  for (const ch of CHARACTERS) {
    const f = (name: string) => ({ key: 'characters', frame: `character_${ch.color}_${name}` });
    anims.create({ key: `${ch.color}_idle`, frames: [f('idle')], frameRate: 1 });
    anims.create({ key: `${ch.color}_walk`, frames: [f('walk_a'), f('walk_b')], frameRate: 9, repeat: -1 });
    anims.create({ key: `${ch.color}_jump`, frames: [f('jump')], frameRate: 1 });
    anims.create({ key: `${ch.color}_hit`, frames: [f('hit')], frameRate: 1 });
    anims.create({ key: `${ch.color}_duck`, frames: [f('duck')], frameRate: 1 });
    anims.create({ key: `${ch.color}_climb`, frames: [f('climb_a'), f('climb_b')], frameRate: 6, repeat: -1 });
  }

  for (const def of Object.values(ENEMIES)) {
    anims.create({
      key: `enemy_${def.id}`,
      frames: def.frames.map((frame) => ({ key: 'enemies', frame })),
      frameRate: def.fps,
      repeat: -1,
    });
  }

  anims.create({
    key: 'flag_green',
    frames: [
      { key: 'tiles', frame: 'flag_green_a' },
      { key: 'tiles', frame: 'flag_green_b' },
    ],
    frameRate: 4,
    repeat: -1,
  });
}
