import Phaser from 'phaser';

/**
 * Callback « process » pour les plateformes traversables par en dessous :
 * on ne collisionne que si l'objet descend et se trouvait au-dessus de la plateforme à la frame précédente.
 */
export function oneWayProcess(a: any, b: any): boolean {
  const body = (a as { body: Phaser.Physics.Arcade.Body }).body;
  const plat = (b as { body: Phaser.Physics.Arcade.StaticBody }).body;
  const prevBottom = body.bottom - body.deltaY();
  return body.velocity.y >= 0 && prevBottom <= plat.top + 12;
}
