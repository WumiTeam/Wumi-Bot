import Phaser from 'phaser';
import { DEPTH } from '../config';

interface BurstOpts {
  count?: number;
  speed?: number;
  scale?: number;
  lifespan?: number;
  gravity?: number;
}

/** Petits effets visuels (étincelles, éclats) construits avec les frames de l'atlas des tuiles. */
export class Effects {
  constructor(private scene: Phaser.Scene) {}

  burst(x: number, y: number, frames: string[], o: BurstOpts = {}): void {
    const emitter = this.scene.add.particles(x, y, 'tiles', {
      frame: frames,
      lifespan: o.lifespan ?? 550,
      speed: { min: 80, max: o.speed ?? 260 },
      angle: { min: -150, max: -30 },
      gravityY: o.gravity ?? 900,
      scale: { start: o.scale ?? 0.35, end: 0 },
      rotate: { min: 0, max: 360 },
      emitting: false,
    });
    emitter.setDepth(DEPTH.fx);
    emitter.explode(o.count ?? 8);
    this.scene.time.delayedCall(1200, () => emitter.destroy());
  }

  coinSparkle(x: number, y: number): void {
    this.burst(x, y, ['star'], { count: 6, scale: 0.28, speed: 200, lifespan: 420 });
  }

  stompPoof(x: number, y: number): void {
    this.burst(x, y, ['star', 'coin_silver'], { count: 8, scale: 0.3, speed: 280 });
  }

  brickDebris(x: number, y: number): void {
    this.burst(x, y, ['brick_brown'], { count: 6, scale: 0.4, speed: 220, gravity: 1100 });
  }
}
