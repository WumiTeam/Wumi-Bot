import Phaser from 'phaser';
import type { TouchControls } from '../ui/TouchControls';

export interface InputState {
  /** -1 gauche, 0 immobile, 1 droite */
  dir: -1 | 0 | 1;
  /** Le saut vient d'être pressé cette frame. */
  jumpPressed: boolean;
  /** Le saut est maintenu. */
  jumpHeld: boolean;
}

/**
 * Abstraction des entrées. Clavier : Q/A/← gauche, D/→ droite, Espace/↑/Z/W saut.
 * (Les commandes tactiles viendront se brancher ici sans toucher au joueur.)
 */
export class Controls {
  private keys: Record<string, Phaser.Input.Keyboard.Key>;
  private touch?: TouchControls;

  constructor(scene: Phaser.Scene, touch?: TouchControls) {
    this.touch = touch;
    this.keys = scene.input.keyboard!.addKeys({
      q: 'Q',
      a: 'A',
      d: 'D',
      left: 'LEFT',
      right: 'RIGHT',
      space: 'SPACE',
      up: 'UP',
      z: 'Z',
      w: 'W',
    }) as Record<string, Phaser.Input.Keyboard.Key>;
  }

  get jumpHeld(): boolean {
    const k = this.keys;
    return k.space.isDown || k.up.isDown || k.z.isDown || k.w.isDown || !!this.touch?.state.jump;
  }

  /** À appeler une seule fois par frame (consomme les « just pressed »). */
  read(): InputState {
    const k = this.keys;
    const left = k.q.isDown || k.a.isDown || k.left.isDown || !!this.touch?.state.left;
    const right = k.d.isDown || k.right.isDown || !!this.touch?.state.right;
    const dir = (right ? 1 : 0) - (left ? 1 : 0);
    const JD = Phaser.Input.Keyboard.JustDown;
    const jumpPressed = [JD(k.space), JD(k.up), JD(k.z), JD(k.w), !!this.touch?.consumeJumpPressed()].some(Boolean);
    return { dir: dir as -1 | 0 | 1, jumpPressed, jumpHeld: this.jumpHeld };
  }
}
