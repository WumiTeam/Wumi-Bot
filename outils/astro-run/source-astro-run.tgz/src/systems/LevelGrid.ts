import { L } from '../data/legend';

/** Rectangle en cases : colonnes c0..c1 (incluses), lignes r0..r0+h-1. */
export interface CellRect {
  c0: number;
  c1: number;
  r0: number;
  h: number;
}

/**
 * Logique pure de la grille du niveau (aucune dépendance à Phaser, donc testable seule) :
 * lecture des cases, auto-tuilage du terrain, fusion des cases en rectangles de collision.
 */
export class LevelGrid {
  readonly cols: number;
  readonly rows: number;
  private cells: string[][];

  constructor(rowStrings: string[]) {
    this.rows = rowStrings.length;
    this.cols = Math.max(...rowStrings.map((r) => r.length));
    this.cells = rowStrings.map((r) => r.padEnd(this.cols, ' ').split(''));
  }

  at(c: number, r: number): string {
    if (c < 0 || c >= this.cols || r < 0 || r >= this.rows) return L.EMPTY;
    return this.cells[r][c];
  }

  /** Cases qui bloquent physiquement de tous côtés (terrain + briques), fusionnées en rectangles. */
  isPhysicalSolid = (c: number, r: number): boolean => {
    const ch = this.at(c, r);
    return ch === L.SOLID || ch === L.BRICK;
  };

  /** Un ennemi qui marche considère ces cases comme du sol. */
  isGroundCell(c: number, r: number): boolean {
    const ch = this.at(c, r);
    return ch === L.SOLID || ch === L.BRICK || ch === L.QUESTION || ch === L.ONE_WAY;
  }

  /** Voisinage pour l'auto-tuilage : les bords gauche/droit/bas de la carte comptent comme du terrain. */
  private isTerrainNeighbour(c: number, r: number): boolean {
    if (r < 0) return false;
    if (c < 0 || c >= this.cols || r >= this.rows) return true;
    return this.cells[r][c] === L.SOLID;
  }

  /** Nom de la pièce de terrain (suffixe de terrain_<thème>_<pièce>) pour la case (c, r). */
  terrainPiece(c: number, r: number): string {
    const up = this.isTerrainNeighbour(c, r - 1);
    const down = this.isTerrainNeighbour(c, r + 1);
    const left = this.isTerrainNeighbour(c - 1, r);
    const right = this.isTerrainNeighbour(c + 1, r);

    if (!up && !down && !left && !right) return 'block';
    if (!left && !right) return !up ? 'vertical_top' : !down ? 'vertical_bottom' : 'vertical_middle';
    if (!up && !down) return !left ? 'horizontal_left' : !right ? 'horizontal_right' : 'horizontal_middle';

    const v = !up ? 'top' : !down ? 'bottom' : '';
    const h = !left ? 'left' : !right ? 'right' : '';
    if (v && h) return `block_${v}_${h}`;
    if (v) return `block_${v}`;
    if (h) return `block_${h}`;
    return 'block_center';
  }

  /** Pièce d'une plateforme traversable (suite horizontale de « = »). */
  oneWayPiece(c: number, r: number): string {
    const left = this.at(c - 1, r) === L.ONE_WAY;
    const right = this.at(c + 1, r) === L.ONE_WAY;
    if (left && right) return 'horizontal_middle';
    if (left) return 'horizontal_right';
    if (right) return 'horizontal_left';
    return 'horizontal_middle';
  }

  /** Case de liquide mortel (eau ou lave). */
  isLiquid = (c: number, r: number): boolean => {
    const ch = this.at(c, r);
    return ch === L.WATER || ch === L.LAVA;
  };

  /** Frame du liquide : la surface si la case du dessus n'est pas du même liquide. */
  liquidFrame(c: number, r: number): string {
    const ch = this.at(c, r);
    const base = ch === L.LAVA ? 'lava' : 'water';
    return this.at(c, r - 1) === ch ? base : `${base}_top`;
  }

  /** Liste toutes les cases contenant l'un des caractères donnés. */
  find(chars: string): { c: number; r: number; ch: string }[] {
    const out: { c: number; r: number; ch: string }[] = [];
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const ch = this.cells[r][c];
        if (chars.includes(ch)) out.push({ c, r, ch });
      }
    }
    return out;
  }

  /**
   * Fusionne les cases vérifiant `pred` en un minimum de rectangles.
   * Moins de corps physiques et surtout aucune « couture » entre tuiles voisines.
   */
  mergeRects(pred: (c: number, r: number) => boolean): CellRect[] {
    const rects: CellRect[] = [];
    let open = new Map<string, CellRect>();
    for (let r = 0; r < this.rows; r++) {
      const next = new Map<string, CellRect>();
      let c = 0;
      while (c < this.cols) {
        if (!pred(c, r)) {
          c++;
          continue;
        }
        let c1 = c;
        while (c1 + 1 < this.cols && pred(c1 + 1, r)) c1++;
        const key = `${c}-${c1}`;
        const prev = open.get(key);
        if (prev) {
          prev.h++;
          next.set(key, prev);
        } else {
          const rect: CellRect = { c0: c, c1, r0: r, h: 1 };
          rects.push(rect);
          next.set(key, rect);
        }
        c = c1 + 1;
      }
      open = next;
    }
    return rects;
  }

  /** Fusion horizontale uniquement (une rangée à la fois), pour les plateformes traversables. */
  mergeRowRuns(pred: (c: number, r: number) => boolean): CellRect[] {
    const out: CellRect[] = [];
    for (let r = 0; r < this.rows; r++) {
      let c = 0;
      while (c < this.cols) {
        if (!pred(c, r)) {
          c++;
          continue;
        }
        let c1 = c;
        while (c1 + 1 < this.cols && pred(c1 + 1, r)) c1++;
        out.push({ c0: c, c1, r0: r, h: 1 });
        c = c1 + 1;
      }
    }
    return out;
  }
}
