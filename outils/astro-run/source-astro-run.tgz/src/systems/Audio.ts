import Phaser from 'phaser';

/** Événements sonores du jeu → fichiers du pack Kenney (public/assets/sounds). */
export type SfxName = 'jump' | 'coin' | 'hurt' | 'stomp' | 'bump' | 'win' | 'select' | 'spring';

const SFX: Record<SfxName, { key: string; volume: number }> = {
  jump: { key: 'sfx_jump', volume: 0.5 },
  coin: { key: 'sfx_coin', volume: 0.6 },
  hurt: { key: 'sfx_hurt', volume: 0.7 },
  stomp: { key: 'sfx_disappear', volume: 0.6 },
  bump: { key: 'sfx_bump', volume: 0.6 },
  win: { key: 'sfx_magic', volume: 0.7 },
  select: { key: 'sfx_select', volume: 0.6 },
  spring: { key: 'sfx_jump-high', volume: 0.6 },
};

/** Liste des fichiers à précharger. */
export const SFX_FILES: string[] = [...new Set(Object.values(SFX).map((s) => s.key)), 'sfx_gem', 'sfx_throw'];

export class Sfx {
  constructor(private scene: Phaser.Scene) {}

  play(name: SfxName): void {
    const def = SFX[name];
    this.scene.sound.play(def.key, { volume: def.volume });
  }
}

/** Applique le volume et le mode muet sauvegardés au gestionnaire de son global. */
export function applyAudioSettings(sound: Phaser.Sound.BaseSoundManager, settings: { muted: boolean; volume: number }): void {
  sound.mute = settings.muted;
  sound.volume = settings.volume;
}
