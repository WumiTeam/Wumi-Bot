import { CHARACTERS } from '../data/characters';
import { defaultSave, MAX_LEVEL, sanitize, type SaveData } from '../shared/saveSchema';

export { defaultSave, sanitize, type SaveData };

/**
 * Où sont stockées les données. Aujourd'hui : le navigateur (localStorage).
 * À l'étape 5, un RemoteBackend enverra les données au serveur, identifié par le joueur Discord authentifié.
 */
export interface SaveBackend {
  load(): Promise<unknown | null>;
  save(data: SaveData): Promise<void>;
  clear(): Promise<void>;
}

export class LocalBackend implements SaveBackend {
  private memory: string | null = null; // secours si le stockage est bloqué (iframe, navigation privée…)

  constructor(private key = 'astro-run:save:v1') {}

  async load(): Promise<unknown | null> {
    let raw: string | null = this.memory;
    try {
      raw = window.localStorage.getItem(this.key) ?? raw;
    } catch {
      /* stockage indisponible */
    }
    try {
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  async save(data: SaveData): Promise<void> {
    const raw = JSON.stringify(data);
    this.memory = raw;
    try {
      window.localStorage.setItem(this.key, raw);
    } catch {
      /* ignoré : on reste en mémoire */
    }
  }

  async clear(): Promise<void> {
    this.memory = null;
    try {
      window.localStorage.removeItem(this.key);
    } catch {
      /* ignoré */
    }
  }
}

export class SaveManager {
  data: SaveData = defaultSave();
  private timer: number | null = null;
  private ready = false;

  constructor(private backend: SaveBackend) {}

  /** Permet de brancher un autre stockage (serveur Discord) avant l'init. */
  setBackend(backend: SaveBackend): void {
    this.backend = backend;
  }

  async init(): Promise<void> {
    if (this.ready) return;
    this.data = sanitize(await this.backend.load());
    this.ready = true;
    // On écrit avant que la page se ferme (fermeture de l'Activity Discord incluse).
    window.addEventListener('pagehide', () => this.flush());
    document.addEventListener('visibilitychange', () => document.visibilityState === 'hidden' && this.flush());
  }

  private persist(): void {
    if (this.timer !== null) return;
    this.timer = window.setTimeout(() => this.flush(), 400);
  }

  flush(): void {
    if (this.timer !== null) {
      window.clearTimeout(this.timer);
      this.timer = null;
    }
    void this.backend.save(this.data).catch((e) => console.error('[save] échec de sauvegarde', e));
  }

  // --- Pièces -------------------------------------------------------------------------
  addCoins(n: number): void {
    if (n <= 0) return;
    this.data.coins += Math.floor(n);
    this.persist();
  }

  // --- Personnages --------------------------------------------------------------------
  owns(id: string): boolean {
    return this.data.owned.includes(id);
  }

  /** Achète un personnage. Retourne false s'il est déjà acheté ou si les pièces manquent. */
  purchase(id: string): boolean {
    const ch = CHARACTERS.find((c) => c.id === id);
    if (!ch || this.owns(id) || this.data.coins < ch.price) return false;
    this.data.coins -= ch.price;
    this.data.owned.push(id);
    this.persist();
    return true;
  }

  select(id: string): boolean {
    if (!this.owns(id)) return false;
    this.data.selected = id;
    this.persist();
    return true;
  }

  // --- Niveaux ------------------------------------------------------------------------
  isUnlocked(levelId: number): boolean {
    return levelId <= this.data.unlockedLevel;
  }

  /** Niveau proposé par « JOUER » : le plus avancé débloqué. */
  nextPlayableLevel(): number {
    return this.data.unlockedLevel;
  }

  bestTime(levelId: number): number | undefined {
    return this.data.bestTimes[String(levelId)];
  }

  bestStars(levelId: number): number {
    return this.data.bestStars[String(levelId)] ?? 0;
  }

  /** Enregistre une victoire : meilleur temps, étoiles, déblocage du niveau suivant. */
  completeLevel(levelId: number, timeMs: number, stars: number): { newBest: boolean; unlockedNext: boolean } {
    const key = String(levelId);
    const prev = this.data.bestTimes[key];
    const newBest = prev === undefined || timeMs < prev;
    if (newBest) this.data.bestTimes[key] = Math.round(timeMs);
    this.data.bestStars[key] = Math.max(this.data.bestStars[key] ?? 0, stars);

    const unlockedNext = levelId >= this.data.unlockedLevel && levelId < MAX_LEVEL;
    if (unlockedNext) this.data.unlockedLevel = levelId + 1;
    this.persist();
    return { newBest, unlockedNext };
  }

  // --- Paramètres ---------------------------------------------------------------------
  setMuted(muted: boolean): void {
    this.data.settings.muted = muted;
    this.persist();
  }

  setVolume(v: number): void {
    this.data.settings.volume = Math.min(1, Math.max(0, v));
    this.persist();
  }

  async reset(): Promise<void> {
    this.data = defaultSave();
    await this.backend.clear();
  }
}

/** Instance unique utilisée par tout le jeu. */
export const saveManager = new SaveManager(new LocalBackend());
