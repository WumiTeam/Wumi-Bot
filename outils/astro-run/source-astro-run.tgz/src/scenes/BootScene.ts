import Phaser from 'phaser';
import { GAME_H, GAME_W, UI_FONT } from '../config';
import { SFX_FILES } from '../systems/Audio';
import { createAnimations } from '../systems/Animations';
import { applyAudioSettings } from '../systems/Audio';
import { setupBackend } from '../net/setup';
import { saveManager } from '../systems/SaveManager';

/** Charge toutes les ressources du pack Kenney (atlas + XML, fonds, sons) puis lance le jeu. */
export class BootScene extends Phaser.Scene {
  private label!: Phaser.GameObjects.Text;

  constructor() {
    super('Boot');
  }

  preload(): void {
    const cx = GAME_W / 2;
    const cy = GAME_H / 2;
    this.cameras.main.setBackgroundColor('#1b2a41');
    this.label = this.add
      .text(cx, cy - 50, 'Chargement…', { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: '34px', color: '#ffffff' })
      .setOrigin(0.5);
    const frame = this.add.rectangle(cx, cy + 10, 440, 30, 0x0b1426).setStrokeStyle(4, 0xffffff);
    const bar = this.add.rectangle(cx - 216, cy + 10, 4, 22, 0xffc83d).setOrigin(0, 0.5);
    this.load.on('progress', (p: number) => {
      bar.setSize(Math.max(4, 432 * p), 22);
      this.label.setText(`Chargement… ${Math.round(p * 100)} %`);
    });
    this.load.on('loaderror', (file: Phaser.Loader.File) => {
      console.error('[Boot] fichier introuvable :', file.src);
    });
    void frame;

    // Atlas : les coordonnées de chaque sprite viennent des fichiers XML de Kenney.
    const atlas = (key: string, name: string) =>
      this.load.atlasXML(key, `assets/atlases/spritesheet-${name}-default.png`, `assets/atlases/spritesheet-${name}-default.xml`);
    atlas('characters', 'characters');
    atlas('enemies', 'enemies');
    atlas('tiles', 'tiles');

    // Fonds : tuiles de 256 px répétées par TileSprite (on les charge entières pour éviter les débords d'atlas).
    for (const name of [
      'clouds',
      'color_hills',
      'color_desert',
      'color_trees',
      'color_mushrooms',
      'fade_hills',
      'fade_desert',
      'fade_trees',
      'fade_mushrooms',
    ]) {
      this.load.image(`bg_${name}`, `assets/backgrounds/background_${name}.png`);
    }

    for (const key of SFX_FILES) this.load.audio(key, `assets/sounds/${key}.ogg`);
  }

  create(): void {
    createAnimations(this);
    // Connexion (Discord si on est dans l'Activity), puis lecture de la sauvegarde, puis menu.
    this.label.setText('Connexion…');
    void (async () => {
      await setupBackend();
      await saveManager.init();
      applyAudioSettings(this.sound, saveManager.data.settings);
      // ?level=3 lance directement un niveau (pratique pour tester)
      const level = Number(new URLSearchParams(window.location.search).get('level'));
      if (level > 0) this.scene.start('Game', { levelId: level });
      else this.scene.start('Menu');
    })();
  }
}
