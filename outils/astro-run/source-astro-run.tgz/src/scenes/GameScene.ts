import Phaser from 'phaser';
import { DEPTH, PLAYER } from '../config';
import { getCharacter } from '../data/characters';
import { ENEMIES } from '../data/enemies';
import { Enemy } from '../entities/Enemy';
import { Player } from '../entities/Player';
import { L } from '../data/legend';
import { getLevel, LEVELS } from '../levels';
import { Sfx } from '../systems/Audio';
import { saveManager } from '../systems/SaveManager';
import { Effects } from '../systems/Effects';
import { Controls } from '../systems/Controls';
import { buildLevel, type CheckpointEntry, type LevelRuntime } from '../systems/LevelBuilder';
import { Parallax } from '../systems/Parallax';
import { oneWayProcess } from '../systems/Physics';
import { Hud } from '../ui/Hud';
import { showPauseScreen, showResultScreen, starsFor, type ScreenHandle } from '../ui/Screens';
import { TouchControls } from '../ui/TouchControls';

type LoseReason = 'enemy' | 'fall';

export class GameScene extends Phaser.Scene {
  private levelId = 1;
  private level!: LevelRuntime;
  private player!: Player;
  private enemies: Enemy[] = [];
  private controls!: Controls;
  private sfx!: Sfx;
  private hud!: Hud;
  private parallax!: Parallax;
  private effects!: Effects;
  private totalCoins = 0;
  private banked = false;
  private screen: ScreenHandle | null = null;

  private lives = PLAYER.lives;
  private coins = 0;
  private elapsedMs = 0;
  private checkpoint = { x: 0, footY: 0 };
  private finished = false;
  private gameOver = false;
  private paused = false;
  private springCooldownUntil = 0;

  constructor() {
    super('Game');
  }

  init(data: { levelId?: number }): void {
    this.levelId = data.levelId ?? 1;
  }

  create(): void {
    // La scène est réutilisée à chaque restart : on réinitialise tout l'état ici.
    this.lives = PLAYER.lives;
    this.coins = 0;
    this.elapsedMs = 0;
    this.finished = false;
    this.gameOver = false;
    this.paused = false;
    this.screen = null;
    this.banked = false;
    // la scène est réutilisée : on lève toute pause laissée par la partie précédente
    this.time.paused = false;
    this.physics.world.resume();
    this.anims.resumeAll();
    this.tweens.resumeAll();
    this.enemies = [];
    this.springCooldownUntil = 0;

    const def = getLevel(this.levelId);
    // Personnage choisi dans la boutique ; ?char=green|pink|purple|yellow le remplace pour tester.
    const character = getCharacter(new URLSearchParams(window.location.search).get('char') ?? saveManager.data.selected);

    this.sfx = new Sfx(this);
    const params = new URLSearchParams(window.location.search);
    const touch = this.sys.game.device.input.touch || params.has('touch') ? new TouchControls(this) : undefined;
    this.controls = new Controls(this, touch);
    this.effects = new Effects(this);
    this.parallax = new Parallax(this, def.theme.hills);
    this.level = buildLevel(this, def);

    this.physics.world.setBounds(0, 0, this.level.widthPx, this.level.heightPx);
    this.physics.world.setBoundsCollision(true, true, false, false);

    this.checkpoint = { ...this.level.start };
    this.player = new Player(this, this.checkpoint.x, this.checkpoint.footY, character.color, this.controls, this.sfx);

    for (const s of this.level.enemySpawns) {
      this.enemies.push(new Enemy(this, s.x, s.footY, ENEMIES[s.id]));
    }

    this.setupCollisions();

    const cam = this.cameras.main;
    cam.setBounds(0, 0, this.level.widthPx, this.level.heightPx);
    cam.startFollow(this.player, true, 0.12, 0.12);
    cam.setDeadzone(100, 80);

    this.totalCoins = this.level.coins.length + this.level.grid.find(L.QUESTION).length;
    this.hud = new Hud(this, `Niveau ${def.id} · ${def.name}`, () => this.togglePause());
    this.hud.setLives(this.lives);

    this.input.keyboard!.on('keydown-ESC', () => this.togglePause());
    this.input.keyboard!.on('keydown-M', () => {
      this.sound.mute = !this.sound.mute;
      saveManager.setMuted(this.sound.mute);
    });
  }

  // ---------------------------------------------------------------------------------------
  // Collisions
  // ---------------------------------------------------------------------------------------
  private setupCollisions(): void {
    const p = this.player;
    const lv = this.level;

    this.physics.add.collider(p, lv.solids);
    this.physics.add.collider(p, lv.oneWays, undefined, oneWayProcess);
    this.physics.add.collider(p, lv.blocks, (_p, block) => this.onBlockHit(block as unknown as Phaser.Physics.Arcade.Sprite));

    this.physics.add.overlap(p, lv.water, () => this.loseLife('fall'));
    this.physics.add.overlap(p, lv.springs, (_p, z) => this.onSpring(z as unknown as Phaser.GameObjects.Zone));
    this.physics.add.overlap(p, lv.checkpoints, (_p, z) => this.onCheckpoint(z as unknown as Phaser.GameObjects.Zone));
    this.physics.add.overlap(p, lv.doorZone, () => this.onGoal());

    for (const e of this.enemies) {
      this.physics.add.collider(e, lv.solids);
      if (e.def.kind === 'walker') {
        this.physics.add.collider(e, lv.oneWays, undefined, oneWayProcess);
        this.physics.add.collider(e, lv.blocks);
      }
      this.physics.add.overlap(p, e, () => this.onEnemyTouch(e));
    }
  }

  private onEnemyTouch(e: Enemy): void {
    if (e.dead || this.player.dead || this.finished) return;
    const pb = this.player.body;
    const eb = e.body;
    const prevBottom = pb.bottom - pb.deltaY();
    const stomp = e.def.stompable && pb.velocity.y > 0 && prevBottom <= eb.top + 16;

    if (stomp) {
      e.squash();
      this.effects.stompPoof(eb.center.x, eb.top);
      this.player.bounce();
      this.sfx.play('stomp');
    } else if (!this.player.isInvincible(this.time.now)) {
      this.loseLife('enemy');
    }
  }

  private onBlockHit(block: Phaser.Physics.Arcade.Sprite): void {
    if (block.getData('used') || !this.player.body.touching.up) return;
    block.setData('used', true);
    block.setFrame('block_empty');
    this.sfx.play('bump');

    this.effects.brickDebris(block.x, block.y - 20);
    // petit rebond du bloc
    this.tweens.add({ targets: block, y: block.y - 12, duration: 80, yoyo: true });

    // pièce qui jaillit
    const pop = this.add.image(block.x, block.y - 40, 'tiles', 'coin_gold').setDepth(DEPTH.fx);
    this.tweens.add({
      targets: pop,
      y: pop.y - 70,
      alpha: 0,
      duration: 450,
      ease: 'Quad.easeOut',
      onComplete: () => pop.destroy(),
    });
    this.addCoins(1);
  }

  private onSpring(zone: Phaser.GameObjects.Zone): void {
    const now = this.time.now;
    if (this.player.dead || now < this.springCooldownUntil || this.player.body.velocity.y < 0) return;
    this.springCooldownUntil = now + 300;
    this.player.springBounce();
    this.sfx.play('spring');
    const img = zone.getData('sprite') as Phaser.GameObjects.Image;
    img.setFrame('spring_out');
    this.time.delayedCall(260, () => img.setFrame('spring'));
  }

  private onCheckpoint(zone: Phaser.GameObjects.Zone): void {
    const entry = zone.getData('entry') as CheckpointEntry;
    if (entry.active) return;
    entry.active = true;
    this.checkpoint = { x: entry.x, footY: entry.footY };
    entry.sprite.play('flag_green');
    this.effects.coinSparkle(entry.x, entry.footY - 90);
    this.sfx.play('select');
  }

  private onGoal(): void {
    if (this.finished || this.player.dead) return;
    this.finished = true;
    this.player.freeze();
    this.level.openDoor();
    this.effects.burst(this.player.x, this.player.y - 40, ['star'], { count: 12, scale: 0.4 });
    this.sfx.play('win');
    this.time.delayedCall(800, () => this.showEndScreen(true));
  }

  // ---------------------------------------------------------------------------------------
  // Vies, pièces, réapparition
  // ---------------------------------------------------------------------------------------
  private loseLife(reason: LoseReason): void {
    if (this.player.dead || this.finished || this.gameOver) return;
    this.lives--;
    this.hud.setLives(this.lives, true);
    this.cameras.main.shake(200, 0.008);
    this.sfx.play('hurt');
    this.player.die();
    if (reason === 'fall') this.cameras.main.stopFollow();

    if (this.lives <= 0) {
      this.gameOver = true;
      this.time.delayedCall(1200, () => this.showEndScreen(false));
    } else {
      this.time.delayedCall(PLAYER.respawnDelayMs, () => this.respawn());
    }
  }

  private respawn(): void {
    const cam = this.cameras.main;
    this.player.respawn(this.checkpoint.x, this.checkpoint.footY, this.time.now);
    cam.startFollow(this.player, true, 0.12, 0.12);
    cam.centerOn(this.player.x, this.player.y);
  }

  private addCoins(n: number): void {
    this.coins += n;
    this.hud.setCoins(this.coins);
    this.sfx.play('coin');
  }

  private updateCoins(time: number): void {
    const b = this.player.body;
    const canCollect = !this.player.dead && !this.finished;
    for (const c of this.level.coins) {
      if (c.got) continue;
      c.img.y = c.baseY + Math.sin(time / 260 + c.phase) * 4;
      if (!canCollect) continue;
      if (Math.abs(b.center.x - c.img.x) < b.halfWidth + 22 && Math.abs(b.center.y - c.img.y) < b.halfHeight + 22) {
        c.got = true;
        this.addCoins(1);
        this.effects.coinSparkle(c.img.x, c.img.y);
        this.tweens.add({
          targets: c.img,
          y: c.img.y - 36,
          scale: 1.5,
          alpha: 0,
          duration: 280,
          onComplete: () => c.img.destroy(),
        });
      }
    }
  }

  // ---------------------------------------------------------------------------------------
  // Boucle principale
  // ---------------------------------------------------------------------------------------
  update(time: number, delta: number): void {
    if (this.paused) return;

    this.parallax.update(this.cameras.main.scrollX, time);
    if (!this.finished && !this.gameOver && !this.player.dead) this.elapsedMs += delta;
    this.hud.setTime(this.elapsedMs);

    this.player.tick(time, delta);
    for (const e of this.enemies) e.tick(time, delta, this.level);
    this.updateCoins(time);

    if (!this.player.dead && this.player.y > this.level.heightPx + 120) this.loseLife('fall');
  }

  // ---------------------------------------------------------------------------------------
  // Pause et écrans de fin
  // ---------------------------------------------------------------------------------------
  private togglePause(): void {
    if (this.finished || this.gameOver) return;
    this.paused = !this.paused;
    if (this.paused) {
      this.physics.world.pause();
      this.anims.pauseAll();
      this.tweens.pauseAll();
      this.time.paused = true;
      this.screen = showPauseScreen(this, { onResume: () => this.togglePause(), onRestart: () => this.restartLevel(), onMenu: () => this.leaveToMenu() });
    } else {
      this.physics.world.resume();
      this.anims.resumeAll();
      this.tweens.resumeAll();
      this.time.paused = false;
      this.screen?.destroy();
      this.screen = null;
    }
  }

  /** Les pièces ramassées pendant la partie rejoignent la bourse (une seule fois par partie). */
  private bankCoins(): void {
    if (this.banked) return;
    this.banked = true;
    saveManager.addCoins(this.coins);
  }

  private restartLevel(levelId = this.levelId): void {
    this.bankCoins();
    this.screen?.destroy();
    this.screen = null;
    this.scene.restart({ levelId });
  }

  private leaveToMenu(): void {
    this.bankCoins();
    this.screen?.destroy();
    this.screen = null;
    // on lève la pause globale avant de quitter (les animations sont partagées entre scènes)
    this.anims.resumeAll();
    this.tweens.resumeAll();
    this.time.paused = false;
    this.scene.start('Menu');
  }

  private showEndScreen(win: boolean): void {
    const nextId = this.levelId + 1;
    let newBest = false;
    if (win) {
      const stars = starsFor(this.coins, this.totalCoins);
      newBest = saveManager.completeLevel(this.levelId, this.elapsedMs, stars).newBest;
    }
    this.bankCoins();
    this.screen = showResultScreen(this, this.sfx, {
      win,
      coins: this.coins,
      totalCoins: this.totalCoins,
      timeMs: this.elapsedMs,
      hasNext: LEVELS.some((l) => l.id === nextId),
      newBest,
      bestMs: saveManager.bestTime(this.levelId),
      onRetry: () => this.restartLevel(),
      onNext: () => this.restartLevel(nextId),
      onMenu: () => this.leaveToMenu(),
    });
  }
}
