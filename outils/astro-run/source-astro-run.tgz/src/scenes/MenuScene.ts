import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_TITLE, GAME_W } from '../config';
import { getCharacter } from '../data/characters';
import { getConnection } from '../net/setup';
import { saveManager } from '../systems/SaveManager';
import { Button, ButtonMenu } from '../ui/Button';
import { addBackdrop, addGround, addLabel, addTitle, CoinBadge } from '../ui/SceneKit';

export class MenuScene extends Phaser.Scene {
  private backdrop!: { update(t: number): void };
  private menu!: ButtonMenu;

  constructor() {
    super('Menu');
  }

  create(): void {
    this.backdrop = addBackdrop(this);
    const groundY = addGround(this);
    new CoinBadge(this);

    // Titre
    const title = addTitle(this, GAME_TITLE, 120, 104);
    this.tweens.add({ targets: title, y: 128, duration: 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // Petite scène décorative sur l'herbe : le personnage choisi, un slime, un drapeau, des buissons.
    const color = getCharacter(saveManager.data.selected).color;
    this.add.image(90, groundY, 'tiles', 'bush').setOrigin(0.5, 1).setDepth(DEPTH.decor).setScale(1.3);
    this.add.sprite(240, groundY + 2, 'characters', `character_${color}_idle`).setOrigin(0.5, 1).setDepth(DEPTH.player).play(`${color}_idle`);
    this.add.sprite(1010, groundY + 1, 'enemies', 'slime_normal_walk_a').setOrigin(0.5, 1).setDepth(DEPTH.enemy).play('enemy_slime');
    this.add.sprite(1150, groundY, 'tiles', 'flag_green_a').setOrigin(0.5, 1).setDepth(DEPTH.decor).play('flag_green');
    this.add.image(1215, groundY, 'tiles', 'bush').setOrigin(0.5, 1).setDepth(DEPTH.decor);

    // Boutons
    const go = (key: string, data?: object) => () => this.scene.start(key, data);
    const entries: [string, 'grass' | 'sand', () => void][] = [
      ['JOUER', 'grass', go('Game', { levelId: saveManager.nextPlayableLevel() })],
      ['NIVEAUX', 'sand', go('LevelSelect')],
      ['PERSONNAGES', 'sand', go('Characters')],
      ['BOUTIQUE', 'sand', go('Shop')],
      ['PARAMÈTRES', 'sand', go('Settings')],
    ];
    const buttons: Button[] = entries.map(([label, color, onClick], i) =>
      new Button(this, GAME_W / 2, 262 + i * 76, { label, widthTiles: 6, color, fontSize: 32, onClick }).setDepth(DEPTH.ui),
    );
    this.menu = new ButtonMenu(this, buttons);
    this.events.once('shutdown', () => this.menu.destroy());

    // État de la connexion, en haut à gauche
    const conn = getConnection();
    if (conn.mode === 'discord' || conn.mode === 'dev') addLabel(this, 24, 30, `Connecté : ${conn.name}`, 22, '#9dffb0', 0);
    else if (conn.mode === 'offline') addLabel(this, 24, 30, 'Hors ligne : progression locale', 22, '#ffb36b', 0);

    void GAME_H;
  }

  update(time: number): void {
    this.backdrop.update(time);
  }
}
