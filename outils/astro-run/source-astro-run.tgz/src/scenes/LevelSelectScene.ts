import Phaser from 'phaser';
import { DEPTH, GAME_W } from '../config';
import { LEVELS } from '../levels';
import { saveManager } from '../systems/SaveManager';
import { Button, ButtonMenu } from '../ui/Button';
import { formatTime } from '../ui/format';
import { createPanel } from '../ui/Panel';
import { addBackButton, addBackdrop, addGround, addLabel, addTitle, CoinBadge } from '../ui/SceneKit';

export class LevelSelectScene extends Phaser.Scene {
  private backdrop!: { update(t: number): void };
  private menu!: ButtonMenu;

  constructor() {
    super('LevelSelect');
  }

  create(): void {
    this.backdrop = addBackdrop(this);
    addGround(this);
    addTitle(this, 'NIVEAUX');
    new CoinBadge(this);

    const buttons: Button[] = [];
    const n = LEVELS.length;
    LEVELS.forEach((level, i) => {
      const cx = GAME_W / 2 + (i - (n - 1) / 2) * 230;
      const cy = 360;
      const unlocked = saveManager.isUnlocked(level.id);

      const panel = createPanel(this, cx, cy, 3, 5, unlocked ? 'grass' : 'stone');
      panel.setDepth(DEPTH.ui - 1);
      addLabel(this, cx, cy - 118, String(level.id), 64).setAlpha(unlocked ? 1 : 0.6);
      const name = addLabel(this, cx, cy - 55, level.name, 22);
      name.setWordWrapWidth(160).setAlpha(unlocked ? 1 : 0.6);

      if (unlocked) {
        const best = saveManager.bestStars(level.id);
        for (let s = 0; s < 3; s++) {
          const star = this.add.image(cx + (s - 1) * 46, cy + 2, 'tiles', 'star').setScale(0.55).setDepth(DEPTH.ui);
          if (s >= best) star.setTint(0x30384f).setAlpha(0.6);
        }
        const t = saveManager.bestTime(level.id);
        addLabel(this, cx, cy + 46, t ? formatTime(t) : '--:--', 22);
      } else {
        this.add.image(cx, cy + 20, 'tiles', 'lock_red').setScale(0.9).setDepth(DEPTH.ui);
      }

      const btn = new Button(this, cx, cy + 112, {
        label: unlocked ? 'Jouer' : 'Verrouillé',
        widthTiles: 2,
        color: unlocked ? 'grass' : 'stone',
        fontSize: 22,
        onClick: () => this.scene.start('Game', { levelId: level.id }),
      }).setDepth(DEPTH.ui);
      btn.setEnabled(unlocked);
      buttons.push(btn);
    });

    buttons.push(addBackButton(this, () => this.scene.start('Menu')));
    this.menu = new ButtonMenu(this, buttons, 0, Math.max(0, saveManager.nextPlayableLevel() - 1));
    this.events.once('shutdown', () => this.menu.destroy());
  }

  update(time: number): void {
    this.backdrop.update(time);
  }
}
