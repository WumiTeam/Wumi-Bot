import Phaser from 'phaser';
import { DEPTH, GAME_W } from '../config';
import { applyAudioSettings } from '../systems/Audio';
import { saveManager } from '../systems/SaveManager';
import { Button, ButtonMenu } from '../ui/Button';
import { createPanel } from '../ui/Panel';
import { addBackButton, addBackdrop, addGround, addLabel, addTitle } from '../ui/SceneKit';

export class SettingsScene extends Phaser.Scene {
  private backdrop!: { update(t: number): void };
  private menu!: ButtonMenu;
  private resetArmed = false;

  constructor() {
    super('Settings');
  }

  create(): void {
    this.resetArmed = false;
    this.backdrop = addBackdrop(this);
    addGround(this);
    addTitle(this, 'PARAMÈTRES');
    createPanel(this, GAME_W / 2, 330, 11, 6, 'stone').setDepth(DEPTH.ui - 1);

    const s = saveManager.data.settings;
    const apply = () => applyAudioSettings(this.sound, saveManager.data.settings);
    const mk = (label: string, x: number, y: number, w: number, color: 'grass' | 'sand' | 'purple', onClick: () => void) =>
      new Button(this, x, y, { label, widthTiles: w, color, fontSize: 28, onClick }).setDepth(DEPTH.ui);

    // Son
    const sound = mk('', GAME_W / 2, 200, 5, 'grass', () => {
      saveManager.setMuted(!saveManager.data.settings.muted);
      apply();
      sound.setLabel(`Son : ${saveManager.data.settings.muted ? 'NON' : 'OUI'}`);
    });
    sound.setLabel(`Son : ${s.muted ? 'NON' : 'OUI'}`);

    // Volume
    const volLabel = addLabel(this, GAME_W / 2, 282, '', 30);
    const refreshVol = () => volLabel.setText(`Volume  ${Math.round(saveManager.data.settings.volume * 100)} %`);
    refreshVol();
    const step = (d: number) => () => {
      saveManager.setVolume(Math.round((saveManager.data.settings.volume + d) * 10) / 10);
      apply();
      refreshVol();
      this.sound.play('sfx_select', { volume: 0.6 });
    };
    const minus = mk('-', GAME_W / 2 - 250, 282, 2, 'sand', step(-0.1));
    const plus = mk('+', GAME_W / 2 + 250, 282, 2, 'sand', step(0.1));

    // Aide des commandes
    addLabel(this, GAME_W / 2, 358, 'Q / D, A / D ou ← → : bouger   ·   Espace : sauter', 22);
    addLabel(this, GAME_W / 2, 392, 'Échap : pause   ·   M : couper le son', 22);

    // Effacer la sauvegarde (avec confirmation)
    const reset = mk('Effacer la sauvegarde', GAME_W / 2, 458, 7, 'purple', () => {
      if (!this.resetArmed) {
        this.resetArmed = true;
        reset.setLabel('Sûr ? Cliquer pour confirmer');
        this.time.delayedCall(3500, () => {
          this.resetArmed = false;
          reset.setLabel('Effacer la sauvegarde');
        });
        return;
      }
      void saveManager.reset().then(() => {
        apply();
        this.scene.restart();
      });
    });

    const back = addBackButton(this, () => this.scene.start('Menu'));
    this.menu = new ButtonMenu(this, [sound, minus, plus, reset, back]);
    this.events.once('shutdown', () => this.menu.destroy());
  }

  update(time: number): void {
    this.backdrop.update(time);
  }
}
