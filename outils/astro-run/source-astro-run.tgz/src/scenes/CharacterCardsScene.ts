import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_W } from '../config';
import { CHARACTERS, type CharacterDef } from '../data/characters';
import { saveManager } from '../systems/SaveManager';
import { Button, ButtonMenu } from '../ui/Button';
import { createPanel } from '../ui/Panel';
import { addBackButton, addBackdrop, addGround, addLabel, addTitle, CoinBadge } from '../ui/SceneKit';

type Mode = 'shop' | 'select';
type GO = Phaser.GameObjects.GameObject;

/**
 * Cartes de personnages, partagées par la BOUTIQUE (acheter + choisir) et PERSONNAGES (choisir).
 * Chaque carte montre l'aperçu animé, le nom, le prix ou le statut, et le bouton adapté.
 */
abstract class CharacterCardsScene extends Phaser.Scene {
  protected abstract mode: Mode;
  protected abstract titleText: string;

  constructor(key: string) {
    super(key);
  }

  private backdrop!: { update(t: number): void };
  private badge!: CoinBadge;
  private feedback!: Phaser.GameObjects.Text;
  private feedbackTimer?: Phaser.Time.TimerEvent;
  private back!: Button;
  private cardItems: GO[] = [];
  private menu: ButtonMenu | null = null;

  create(): void {
    this.cardItems = [];
    this.menu = null;
    this.backdrop = addBackdrop(this);
    addGround(this);
    addTitle(this, this.titleText);
    this.badge = new CoinBadge(this);
    this.feedback = addLabel(this, GAME_W / 2, GAME_H - 170, '', 30, '#ffe27a');
    this.back = addBackButton(this, () => this.scene.start('Menu'));
    this.events.once('shutdown', () => this.menu?.destroy());
    this.buildCards(0);
  }

  update(time: number): void {
    this.backdrop.update(time);
  }

  private say(message: string): void {
    this.feedback.setText(message);
    this.feedbackTimer?.remove();
    this.feedbackTimer = this.time.delayedCall(2600, () => this.feedback.setText(''));
  }

  private track<T extends GO>(o: T): T {
    this.cardItems.push(o);
    return o;
  }

  /** (Re)construit toutes les cartes : appelé au départ et après chaque achat ou changement de sélection. */
  private buildCards(focus: number): void {
    this.menu?.destroy();
    this.cardItems.forEach((o) => o.destroy());
    this.cardItems = [];
    this.badge.refresh();

    const buttons: Button[] = [];
    CHARACTERS.forEach((ch, i) => {
      const cx = GAME_W / 2 + (i - (CHARACTERS.length - 1) / 2) * 220;
      buttons.push(this.buildCard(ch, cx, 350, i));
    });
    buttons.push(this.back);
    this.menu = new ButtonMenu(this, buttons, 0, focus);
  }

  private buildCard(ch: CharacterDef, cx: number, cy: number, index: number): Button {
    const owned = saveManager.owns(ch.id);
    const selected = saveManager.data.selected === ch.id;
    const hidden = this.mode === 'select' && !owned; // dans PERSONNAGES, les non possédés sont grisés

    this.track(createPanel(this, cx, cy, 3, 5, selected ? 'grass' : owned ? 'sand' : 'stone')).setDepth(DEPTH.ui - 1);

    // Aperçu : le personnage sélectionné marche sur place.
    const preview = this.track(this.add.sprite(cx, cy - 88, 'characters', `character_${ch.color}_idle`).setScale(0.95).setDepth(DEPTH.ui));
    if (selected) preview.play(`${ch.color}_walk`);
    if (hidden) preview.setTint(0x20263a);

    this.track(addLabel(this, cx, cy - 6, ch.name, 30));

    // Prix ou statut
    if (selected) {
      this.track(addLabel(this, cx, cy + 38, 'Sélectionné', 22, '#ffe27a'));
    } else if (owned) {
      this.track(addLabel(this, cx, cy + 38, 'Acheté', 22, '#9dffb0'));
    } else {
      const canPay = saveManager.data.coins >= ch.price;
      this.track(this.add.image(cx - 34, cy + 38, 'tiles', 'hud_coin').setScale(0.5).setDepth(DEPTH.ui));
      this.track(addLabel(this, cx - 10, cy + 40, String(ch.price), 26, canPay ? '#ffffff' : '#ff8d8d', 0));
    }

    // Bouton
    let label: string;
    let onClick: () => void;
    if (selected) {
      label = 'Choisi';
      onClick = () => undefined;
    } else if (owned) {
      label = 'Choisir';
      onClick = () => {
        saveManager.select(ch.id);
        this.say(`${ch.name} est prêt à jouer !`);
        this.buildCards(index);
      };
    } else if (this.mode === 'shop') {
      label = 'Acheter';
      onClick = () => {
        if (saveManager.purchase(ch.id)) {
          this.sound.play('sfx_coin', { volume: 0.7 });
          this.say(`${ch.name} débloqué !`);
          this.buildCards(index);
        } else {
          const missing = ch.price - saveManager.data.coins;
          this.sound.play('sfx_hurt', { volume: 0.5 });
          this.say(`Il te manque ${missing} pièce${missing > 1 ? 's' : ''}`);
          this.cameras.main.shake(120, 0.004);
        }
      };
    } else {
      label = 'Boutique';
      onClick = () => this.scene.start('Shop');
    }

    const btn = this.track(new Button(this, cx, cy + 108, { label, widthTiles: 2, color: selected ? 'stone' : 'grass', fontSize: 22, onClick }).setDepth(DEPTH.ui));
    btn.setEnabled(!selected);
    return btn;
  }
}

export class ShopScene extends CharacterCardsScene {
  protected mode: Mode = 'shop';
  protected titleText = 'BOUTIQUE';
  constructor() {
    super('Shop');
  }
}

export class CharactersScene extends CharacterCardsScene {
  protected mode: Mode = 'select';
  protected titleText = 'PERSONNAGES';
  constructor() {
    super('Characters');
  }
}
