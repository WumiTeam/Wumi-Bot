/**
 * Intégration Discord Embedded App SDK.
 * Déroulé : SDK prêt → autorisation (code OAuth2) → notre serveur échange le code et VÉRIFIE le joueur auprès de Discord
 * → il renvoie un jeton de session signé → le SDK s'authentifie. L'identité ne vient jamais du client.
 */
export interface ActivityContext {
  instanceId: string;
  channelId: string | null;
  guildId: string | null;
}

export interface DiscordConnection {
  session: string;
  user: { name: string; avatar: string | null };
  context: ActivityContext;
  /** Redemande une session (jeton expiré). */
  refresh: () => Promise<string>;
}

/** Discord ajoute frame_id et instance_id à l'URL de l'Activity. */
export function isDiscordActivity(): boolean {
  const p = new URLSearchParams(window.location.search);
  return p.has('frame_id') && p.has('instance_id');
}

/** Wumi : signale au serveur l'etape ou la connexion bloque (diagnostic). */
function signaler(etape: string, message: string): void {
  try {
    void fetch('/astro/api/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ etape, message: String(message).slice(0, 300), ua: navigator.userAgent.slice(0, 120) }),
    }).catch(() => undefined);
  } catch {
    /* rien */
  }
}

/** Une etape avec delai maximum : jamais de chargement infini. */
async function etape<T>(nom: string, travail: Promise<T>, ms: number): Promise<T> {
  let minuterie: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      travail,
      new Promise<T>((_, rejeter) => {
        minuterie = setTimeout(() => rejeter(new Error(`délai dépassé (${nom})`)), ms);
      }),
    ]);
  } catch (e) {
    signaler(nom, e instanceof Error ? e.message : String(e));
    throw e;
  } finally {
    if (minuterie) clearTimeout(minuterie);
  }
}

export async function connectDiscord(): Promise<DiscordConnection> {
  signaler('debut', window.location.pathname);
  // Wumi : l'identifiant de l'application est donne par le serveur du bot.
  let clientId = import.meta.env.VITE_DISCORD_CLIENT_ID as string | undefined;
  if (!clientId) {
    const r = await etape('config', fetch('/api/config'), 10_000);
    clientId = ((await r.json()) as { client_id?: string }).client_id;
  }
  if (!clientId) throw new Error('Identifiant de l\'application Discord introuvable');

  // Chargé uniquement dans Discord : le SDK n'alourdit pas la version navigateur.
  const { DiscordSDK } = await import('@discord/embedded-app-sdk');
  const sdk = new DiscordSDK(clientId);
  await etape('ready', sdk.ready(), 15_000);

  const authorizeAndExchange = async () => {
    const { code } = await etape('authorize', sdk.commands.authorize({
      client_id: clientId,
      response_type: 'code',
      state: '',
      prompt: 'none',
      scope: ['identify'],
    }), 120_000);
    const res = await etape('token', fetch('/astro/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    }), 15_000);
    if (!res.ok) {
      signaler('token', `HTTP ${res.status}`);
      throw new Error(`Échange du code refusé (HTTP ${res.status})`);
    }
    return (await res.json()) as { access_token: string; session: string; user: { name: string; avatar: string | null } };
  };

  const first = await authorizeAndExchange();
  const auth = await etape('authenticate', sdk.commands.authenticate({ access_token: first.access_token }), 15_000);
  if (!auth) throw new Error('sdk.commands.authenticate a échoué');
  signaler('ok', 'connecté');

  return {
    session: first.session,
    user: first.user,
    context: { instanceId: sdk.instanceId, channelId: sdk.channelId ?? null, guildId: sdk.guildId ?? null },
    refresh: async () => (await authorizeAndExchange()).session,
  };
}
