/** Constantes globales du jeu. Tout le « game feel » se règle ici. */

export const GAME_TITLE = 'WUMI RUN';
export const TILE = 64;
export const GAME_W = 1280;
export const GAME_H = 768; // = 12 rangées de 64 px

export const PHYSICS = {
  gravity: 1800,
};

export const PLAYER = {
  lives: 3,
  /** Les sprites de personnage font 128 px ; ils sont affichés à cette échelle (proportions conservées). */
  scale: 0.6,
  maxSpeed: 330,
  accelGround: 2800,
  accelAir: 1900,
  frictionGround: 3200,
  frictionAir: 900,
  jumpVelocity: 820,
  /** Multiplicateur de vitesse verticale quand on relâche le saut (saut variable). */
  jumpCut: 0.45,
  coyoteMs: 110,
  bufferMs: 120,
  maxFallSpeed: 1100,
  stompBounce: 480,
  stompBounceHeld: 760,
  springBounce: 1150,
  invincibleMs: 2000,
  deathHop: 650,
  respawnDelayMs: 1000,
  /** Hitbox exprimée en pixels du sprite source (128×128). Le bas du corps est à y = 126. */
  body: { w: 68, h: 90, ox: 30, oy: 36 },
  /** Distance du centre du sprite à la base des pieds, en pixels source. */
  feetFromCenter: 62,
  /** Permet un double saut. Désactivé : il n'est pas pertinent pour ce premier niveau. */
  doubleJump: false,
};

/** Ordre d'affichage (z-index) des couches. */
export const DEPTH = {
  background: -100,
  decor: 2,
  terrain: 3,
  water: 4,
  door: 5,
  coin: 8,
  enemy: 10,
  player: 12,
  fx: 20,
  ui: 100,
  overlay: 200,
};

export const UI_FONT = '"Trebuchet MS", "Arial Rounded MT Bold", Arial, sans-serif';
