import Phaser from 'phaser';
import { TILE, UI_FONT } from '../config';

export type ButtonColor = 'grass' | 'sand' | 'purple' | 'snow' | 'dirt' | 'stone';

export interface ButtonOpts {
  label: string;
  /** Largeur en tuiles (minimum 2). */
  widthTiles?: number;
  color?: ButtonColor;
  fontSize?: number;
  onClick: () => void;
}

/** Bouton fait de 3 pièces « horizontal » du terrain Kenney. Souris, tactile et clavier (via ButtonMenu). */
export class Button extends Phaser.GameObjects.Container {
  private labelText: Phaser.GameObjects.Text;
  private onClick: () => void;
  private hover = false;
  private kbFocus = false;
  private enabled = true;

  constructor(scene: Phaser.Scene, x: number, y: number, o: ButtonOpts) {
    super(scene, x, y);
    this.onClick = o.onClick;

    const n = Math.max(2, o.widthTiles ?? 4);
    const w = n * TILE;
    const color = o.color ?? 'grass';
    for (let i = 0; i < n; i++) {
      const piece = i === 0 ? 'left' : i === n - 1 ? 'right' : 'middle';
      this.add(scene.add.image(-w / 2 + i * TILE, -TILE / 2, 'tiles', `terrain_${color}_horizontal_${piece}`).setOrigin(0, 0));
    }
    this.labelText = scene.add
      .text(0, 6, o.label, {
        fontFamily: UI_FONT,
        fontStyle: 'bold',
        fontSize: `${o.fontSize ?? 30}px`,
        color: '#ffffff',
        stroke: '#1f2a44',
        strokeThickness: 7,
      })
      .setOrigin(0.5);
    this.add(this.labelText);

    this.setSize(w, TILE);
    this.setInteractive(new Phaser.Geom.Rectangle(-w / 2, -TILE / 2, w, TILE), Phaser.Geom.Rectangle.Contains);
    if (this.input) this.input.cursor = 'pointer';
    this.setScrollFactor(0);

    this.on('pointerover', () => {
      this.hover = true;
      this.refresh();
    });
    this.on('pointerout', () => {
      this.hover = false;
      this.refresh();
    });
    this.on('pointerdown', () => this.enabled && this.setScale(0.96));
    this.on('pointerup', () => {
      this.refresh();
      this.activate();
    });

    scene.add.existing(this);
  }

  /** Déclenche l'action du bouton (clic ou touche Entrée). */
  activate(): void {
    if (!this.enabled) return;
    this.scene.sound.play('sfx_select', { volume: 0.6 });
    this.onClick();
  }

  isEnabled(): boolean {
    return this.enabled;
  }

  /** Un bouton désactivé reste visible mais grisé et ne réagit plus. */
  setEnabled(e: boolean): this {
    this.enabled = e;
    this.setAlpha(e ? 1 : 0.55);
    if (this.input) this.input.cursor = e ? 'pointer' : 'default';
    this.refresh();
    return this;
  }

  setLabel(text: string): this {
    this.labelText.setText(text);
    return this;
  }

  setKeyboardFocus(f: boolean): void {
    this.kbFocus = f;
    this.refresh();
  }

  private refresh(): void {
    const on = this.enabled && (this.hover || this.kbFocus);
    this.setScale(on ? 1.06 : 1);
    this.labelText.setColor(on ? '#ffe27a' : '#ffffff');
  }
}

/** Navigation clavier dans un groupe de boutons (↑↓←→ + Entrée/Espace). */
export class ButtonMenu {
  private index = 0;
  private readyAt: number;
  private handler: (e: KeyboardEvent) => void;

  constructor(
    private scene: Phaser.Scene,
    private buttons: Button[],
    delayMs = 0,
    startIndex = 0,
  ) {
    this.index = Math.min(Math.max(0, startIndex), buttons.length - 1);
    this.readyAt = performance.now() + delayMs;
    buttons.forEach((b, i) =>
      b.on('pointerover', () => {
        if (!b.isEnabled()) return;
        this.index = i;
        this.apply();
      }),
    );
    this.apply();

    this.handler = (e: KeyboardEvent) => {
      if (e.repeat || performance.now() < this.readyAt) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowRight') this.move(1);
      else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') this.move(-1);
      else if (e.key === 'Enter' || e.key === ' ') this.buttons[this.index]?.activate();
    };
    scene.input.keyboard?.on('keydown', this.handler);
  }

  private move(d: number): void {
    const n = this.buttons.length;
    for (let k = 0; k < n; k++) {
      this.index = (this.index + d + n) % n;
      if (this.buttons[this.index].isEnabled()) break; // on saute les boutons désactivés
    }
    this.apply();
  }

  get focusIndex(): number {
    return this.index;
  }

  private apply(): void {
    this.buttons.forEach((b, i) => b.setKeyboardFocus(i === this.index));
  }

  destroy(): void {
    this.scene.input.keyboard?.off('keydown', this.handler);
  }
}
