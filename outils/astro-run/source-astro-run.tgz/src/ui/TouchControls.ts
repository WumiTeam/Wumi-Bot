import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_W } from '../config';

/** Boutons tactiles : panneaux « flèche » du pack pour gauche/droite, ressort pour sauter. */
export class TouchControls {
  readonly state = { left: false, right: false, jump: false };
  private jumpPrev = false;

  constructor(scene: Phaser.Scene) {
    scene.input.addPointer(2); // multitouch : marcher + sauter en même temps
    const y = GAME_H - 100;
    this.makeButton(scene, 110, y, 'sign_left', 'left');
    this.makeButton(scene, 270, y, 'sign_right', 'right');
    this.makeButton(scene, GAME_W - 120, y, 'spring_out', 'jump');
  }

  private makeButton(scene: Phaser.Scene, x: number, y: number, frame: string, key: 'left' | 'right' | 'jump'): void {
    const img = scene.add
      .image(x, y, 'tiles', frame)
      .setScale(1.7)
      .setAlpha(0.6)
      .setScrollFactor(0)
      .setDepth(DEPTH.ui)
      .setInteractive();
    const press = () => {
      this.state[key] = true;
      img.setAlpha(0.95);
    };
    const release = () => {
      this.state[key] = false;
      img.setAlpha(0.6);
    };
    img.on('pointerdown', press);
    img.on('pointerover', (p: Phaser.Input.Pointer) => p.isDown && press());
    img.on('pointerup', release);
    img.on('pointerout', release);
  }

  /** Vrai une seule fois à l'appui du bouton de saut. */
  consumeJumpPressed(): boolean {
    const pressed = this.state.jump && !this.jumpPrev;
    this.jumpPrev = this.state.jump;
    return pressed;
  }
}
