import Phaser from 'phaser';
import { TILE } from '../config';

/**
 * Panneau d'interface : on assemble les 9 pièces d'un bloc de terrain Kenney
 * (coins, bords, centre), exactement comme pour une plateforme du jeu.
 */
export function createPanel(
  scene: Phaser.Scene,
  cx: number,
  cy: number,
  wTiles: number,
  hTiles: number,
  terrain: string = 'stone',
): Phaser.GameObjects.Container {
  const box = scene.add.container(cx - (wTiles * TILE) / 2, cy - (hTiles * TILE) / 2);
  for (let row = 0; row < hTiles; row++) {
    for (let col = 0; col < wTiles; col++) {
      const v = row === 0 ? 'top' : row === hTiles - 1 ? 'bottom' : '';
      const h = col === 0 ? 'left' : col === wTiles - 1 ? 'right' : '';
      const piece = v && h ? `block_${v}_${h}` : v ? `block_${v}` : h ? `block_${h}` : 'block_center';
      box.add(scene.add.image(col * TILE, row * TILE, 'tiles', `terrain_${terrain}_${piece}`).setOrigin(0, 0));
    }
  }
  return box;
}
