import Phaser from 'phaser';
import { DEPTH, GAME_W, PLAYER, UI_FONT } from '../config';
import { Button } from './Button';
import { formatTime } from './format';

/** Interface en jeu : pièces (chiffres du pack), cœurs de vie, chrono, nom du niveau, bouton pause. */
export class Hud {
  private scene: Phaser.Scene;
  private digits: Phaser.GameObjects.Image[] = [];
  private hearts: Phaser.GameObjects.Image[] = [];
  private timerText: Phaser.GameObjects.Text;
  private lastSecond = -1;

  constructor(scene: Phaser.Scene, levelLabel: string, onPause: () => void) {
    this.scene = scene;
    const ui = <T extends Phaser.GameObjects.Image | Phaser.GameObjects.Text>(o: T): T => {
      o.setScrollFactor(0);
      o.setDepth(DEPTH.ui);
      return o;
    };

    ui(scene.add.image(46, 46, 'tiles', 'hud_coin').setScale(0.85));
    ui(scene.add.image(100, 48, 'tiles', 'hud_character_multiply').setScale(0.7));

    for (let i = 0; i < PLAYER.lives; i++) {
      const x = GAME_W - 52 - (PLAYER.lives - 1 - i) * 62;
      this.hearts.push(ui(scene.add.image(x, 46, 'tiles', 'hud_heart').setScale(0.9)));
    }

    this.timerText = ui(
      scene.add
        .text(30, 96, '0:00', { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: '26px', color: '#ffffff', stroke: '#1f2a44', strokeThickness: 6 })
        .setOrigin(0, 0.5),
    );

    ui(
      scene.add
        .text(GAME_W / 2, 30, levelLabel, { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: '26px', color: '#ffffff', stroke: '#1f2a44', strokeThickness: 6 })
        .setOrigin(0.5, 0.5),
    );

    // Bouton pause (petit, sous les cœurs)
    const pause = new Button(scene, GAME_W - 90, 118, { label: 'II', widthTiles: 2, color: 'sand', fontSize: 34, onClick: onPause });
    pause.setScale(0.7).setDepth(DEPTH.ui);

    this.setCoins(0, false);
  }

  setCoins(n: number, pulse = true): void {
    this.digits.forEach((d) => d.destroy());
    this.digits = [];
    const str = String(n);
    for (let i = 0; i < str.length; i++) {
      const img = this.scene.add
        .image(146 + i * 30, 48, 'tiles', `hud_character_${str[i]}`)
        .setScale(0.8)
        .setScrollFactor(0)
        .setDepth(DEPTH.ui);
      this.digits.push(img);
      if (pulse) this.scene.tweens.add({ targets: img, scale: 1.1, duration: 90, yoyo: true });
    }
  }

  setLives(n: number, shake = false): void {
    this.hearts.forEach((h, i) => h.setFrame(i < n ? 'hud_heart' : 'hud_heart_empty'));
    if (shake) {
      this.scene.tweens.add({ targets: this.hearts, angle: { from: -14, to: 14 }, duration: 60, yoyo: true, repeat: 3, onComplete: () => this.hearts.forEach((h) => h.setAngle(0)) });
    }
  }

  setTime(ms: number): void {
    const sec = Math.floor(ms / 1000);
    if (sec === this.lastSecond) return;
    this.lastSecond = sec;
    this.timerText.setText(formatTime(ms, false));
  }
}
