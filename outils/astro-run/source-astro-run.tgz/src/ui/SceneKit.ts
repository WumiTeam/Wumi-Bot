import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_W, TILE, UI_FONT } from '../config';
import { saveManager } from '../systems/SaveManager';
import { Parallax } from '../systems/Parallax';
import { Button } from './Button';

/** Fond animé commun aux menus (même parallaxe que le jeu, qui défile doucement). */
export function addBackdrop(scene: Phaser.Scene, hills = 'hills'): { update(timeMs: number): void } {
  const parallax = new Parallax(scene, hills);
  return { update: (t) => parallax.update(t * 0.03, t) };
}

/** Deux rangées de terrain en bas de l'écran. */
export function addGround(scene: Phaser.Scene, terrain = 'grass'): number {
  const topY = GAME_H - TILE * 2;
  for (let x = 0; x < GAME_W; x += TILE) {
    scene.add.image(x, topY, 'tiles', `terrain_${terrain}_block_top`).setOrigin(0, 0).setDepth(DEPTH.terrain);
    scene.add.image(x, topY + TILE, 'tiles', `terrain_${terrain}_block_center`).setOrigin(0, 0).setDepth(DEPTH.terrain);
  }
  return topY;
}

export function addTitle(scene: Phaser.Scene, text: string, y = 64, size = 60): Phaser.GameObjects.Text {
  return scene.add
    .text(GAME_W / 2, y, text, { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: `${size}px`, color: '#ffc83d', stroke: '#101a30', strokeThickness: 12 })
    .setOrigin(0.5)
    .setDepth(DEPTH.ui);
}

export function addLabel(
  scene: Phaser.Scene,
  x: number,
  y: number,
  text: string,
  size = 26,
  color = '#ffffff',
  originX = 0.5,
): Phaser.GameObjects.Text {
  return scene.add
    .text(x, y, text, { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: `${size}px`, color, stroke: '#101a30', strokeThickness: Math.max(4, size / 4), align: 'center' })
    .setOrigin(originX, 0.5)
    .setDepth(DEPTH.ui);
}

/** Solde de pièces en haut à droite. */
export class CoinBadge {
  private text: Phaser.GameObjects.Text;

  constructor(scene: Phaser.Scene, x = GAME_W - 190, y = 56) {
    scene.add.image(x, y, 'tiles', 'hud_coin').setScale(0.85).setDepth(DEPTH.ui);
    this.text = addLabel(scene, x + 40, y + 2, '', 36, '#ffffff', 0);
    this.refresh();
  }

  refresh(): void {
    this.text.setText(String(saveManager.data.coins));
  }
}

export function addBackButton(scene: Phaser.Scene, onClick: () => void): Button {
  return new Button(scene, 170, GAME_H - 170, { label: '< Retour', widthTiles: 3, color: 'sand', fontSize: 28, onClick }).setDepth(DEPTH.ui);
}
