import Phaser from 'phaser';
import { DEPTH, GAME_H, GAME_W, UI_FONT } from '../config';
import type { Sfx } from '../systems/Audio';
import { Button, ButtonMenu } from './Button';
import { formatTime } from './format';
import { createPanel } from './Panel';

export interface ScreenHandle {
  destroy(): void;
}

type Item = Phaser.GameObjects.Image | Phaser.GameObjects.Text | Phaser.GameObjects.Container | Phaser.GameObjects.Rectangle;

const CX = GAME_W / 2;
const CY = GAME_H / 2;

/** Rassemble les éléments d'un écran pour pouvoir tous les détruire ensemble. */
class Screen implements ScreenHandle {
  items: Item[] = [];
  menu: ButtonMenu | null = null;

  constructor(
    public scene: Phaser.Scene,
    panelW: number,
    panelH: number,
  ) {
    // Voile sombre qui absorbe aussi les clics (rien ne passe au jeu derrière).
    const dim = scene.add.rectangle(CX, CY, GAME_W, GAME_H, 0x0b1426, 0.62).setInteractive();
    this.add(dim, 0);
    this.add(createPanel(scene, CX, CY, panelW, panelH, 'stone'), 1);
  }

  add<T extends Item>(item: T, layer = 2): T {
    item.setScrollFactor(0).setDepth(DEPTH.overlay + layer);
    this.items.push(item);
    return item;
  }

  title(text: string, y: number, color = '#ffc83d'): void {
    this.add(
      this.scene.add
        .text(CX, y, text, { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: '54px', color, stroke: '#101a30', strokeThickness: 10 })
        .setOrigin(0.5),
    );
  }

  text(text: string, x: number, y: number, size = 30, origin = 0.5): Phaser.GameObjects.Text {
    return this.add(
      this.scene.add
        .text(x, y, text, { fontFamily: UI_FONT, fontStyle: 'bold', fontSize: `${size}px`, color: '#ffffff', stroke: '#101a30', strokeThickness: 7 })
        .setOrigin(origin, 0.5),
    );
  }

  button(label: string, x: number, y: number, widthTiles: number, color: 'grass' | 'sand' | 'purple', onClick: () => void, fontSize = 30): Button {
    return this.add(new Button(this.scene, x, y, { label, widthTiles, color, onClick, fontSize }), 3);
  }

  destroy(): void {
    this.menu?.destroy();
    this.items.forEach((i) => i.destroy());
    this.items = [];
  }
}

// -------------------------------------------------------------------------------------------
export function showPauseScreen(scene: Phaser.Scene, h: { onResume: () => void; onRestart: () => void; onMenu: () => void }): ScreenHandle {
  const s = new Screen(scene, 8, 6);
  s.title('PAUSE', CY - 125);
  const b1 = s.button('Reprendre', CX, CY - 30, 5, 'grass', h.onResume);
  const b2 = s.button('Recommencer', CX, CY + 50, 5, 'sand', h.onRestart);
  const b3 = s.button('Menu principal', CX, CY + 130, 5, 'sand', h.onMenu);
  s.menu = new ButtonMenu(scene, [b1, b2, b3]);
  return s;
}

// -------------------------------------------------------------------------------------------
export interface ResultOpts {
  win: boolean;
  coins: number;
  totalCoins: number;
  timeMs: number;
  hasNext: boolean;
  /** Victoire : nouveau meilleur temps ? et ancien record à afficher sinon. */
  newBest?: boolean;
  bestMs?: number;
  onRetry: () => void;
  onNext: () => void;
  onMenu: () => void;
}

/** Nombre d'étoiles : 1 pour avoir fini, +1 à 50 % des pièces, +1 à 90 %. */
export function starsFor(coins: number, total: number): number {
  const ratio = total > 0 ? coins / total : 1;
  return 1 + (ratio >= 0.5 ? 1 : 0) + (ratio >= 0.9 ? 1 : 0);
}

export function showResultScreen(scene: Phaser.Scene, sfx: Sfx, o: ResultOpts): ScreenHandle {
  const s = new Screen(scene, 10, 7);

  if (!o.win) {
    s.title('GAME OVER', CY - 140, '#ff6b6b');
    s.add(scene.add.image(CX - 85, CY - 40, 'tiles', 'hud_coin').setScale(0.9));
    s.text(`${o.coins} pièce${o.coins > 1 ? 's' : ''}`, CX - 45, CY - 36, 34, 0);
    s.text('Pièces ajoutées à ta bourse', CX, CY + 20, 22);
    const retry = s.button('Recommencer', CX + 125, CY + 110, 4, 'grass', o.onRetry, 28);
    const menu = s.button('Menu', CX - 125, CY + 110, 4, 'sand', o.onMenu, 28);
    s.menu = new ButtonMenu(scene, [menu, retry], 400, 1);
    return s;
  }

  s.title('NIVEAU TERMINÉ !', CY - 160);

  // Étoiles (s'affichent une à une)
  const stars = starsFor(o.coins, o.totalCoins);
  for (let i = 0; i < 3; i++) {
    const star = s.add(scene.add.image(CX + (i - 1) * 96, CY - 82, 'tiles', 'star').setScale(0));
    const earned = i < stars;
    if (!earned) star.setTint(0x30384f).setAlpha(0.55);
    scene.tweens.add({
      targets: star,
      scale: 1.3,
      angle: earned ? 360 : 0,
      delay: 350 + i * 280,
      duration: 380,
      ease: 'Back.easeOut',
      onStart: () => earned && sfx.play('coin'),
    });
  }

  s.add(scene.add.image(CX - 175, CY - 2, 'tiles', 'hud_coin').setScale(0.8));
  s.text(`${o.coins} / ${o.totalCoins}`, CX - 130, CY + 2, 32, 0);
  s.text(`Temps  ${formatTime(o.timeMs)}`, CX + 10, CY + 2, 32, 0);

  if (o.newBest) s.text('Nouveau record !', CX, CY + 48, 28).setColor('#ffc83d');
  else if (o.bestMs) s.text(`Record  ${formatTime(o.bestMs)}`, CX, CY + 48, 24);

  const buttons: Button[] = [];
  buttons.push(s.button('Menu', o.hasNext ? CX - 215 : CX - 110, CY + 125, 3, 'sand', o.onMenu, 26));
  buttons.push(s.button('Rejouer', o.hasNext ? CX : CX + 110, CY + 125, 3, 'sand', o.onRetry, 26));
  if (o.hasNext) buttons.push(s.button('Suivant', CX + 215, CY + 125, 3, 'grass', o.onNext, 26));
  s.menu = new ButtonMenu(scene, buttons, 900, buttons.length - 1);
  return s;
}
