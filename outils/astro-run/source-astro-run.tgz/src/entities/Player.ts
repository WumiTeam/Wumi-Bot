import Phaser from 'phaser';
import { DEPTH, PLAYER } from '../config';
import type { Controls } from '../systems/Controls';
import type { Sfx } from '../systems/Audio';

function approach(value: number, target: number, step: number): number {
  return value < target ? Math.min(value + step, target) : Math.max(value - step, target);
}

/** Le personnage jouable : déplacement avec inertie, saut variable, coyote time, saut bufferisé. */
export class Player extends Phaser.Physics.Arcade.Sprite {
  declare body: Phaser.Physics.Arcade.Body;

  readonly color: string;
  dead = false;
  invincibleUntil = 0;

  private controls: Controls;
  private sfx: Sfx;
  private coyote = 0;
  private buffer = 0;
  private jumpCuttable = false;
  private facing: 1 | -1 = 1;
  private frozen = false;

  constructor(scene: Phaser.Scene, x: number, footY: number, color: string, controls: Controls, sfx: Sfx) {
    super(scene, x, footY - PLAYER.feetFromCenter * PLAYER.scale, 'characters', `character_${color}_idle`);
    this.color = color;
    this.controls = controls;
    this.sfx = sfx;

    scene.add.existing(this);
    scene.physics.add.existing(this);

    this.setScale(PLAYER.scale);
    this.setDepth(DEPTH.player);
    this.body.setSize(PLAYER.body.w, PLAYER.body.h, false);
    this.body.setOffset(PLAYER.body.ox, PLAYER.body.oy);
    this.body.setCollideWorldBounds(true);
  }

  tick(time: number, delta: number): void {
    const body = this.body;

    if (this.dead) {
      this.anims.play(`${this.color}_hit`, true);
      return;
    }

    const dt = delta / 1000;
    const onGround = body.blocked.down || body.touching.down;
    const input = this.frozen ? { dir: 0 as const, jumpPressed: false, jumpHeld: false } : this.controls.read();

    this.coyote = onGround ? PLAYER.coyoteMs : this.coyote - delta;
    this.buffer = input.jumpPressed ? PLAYER.bufferMs : this.buffer - delta;

    // --- Horizontal ---
    let vx = body.velocity.x;
    if (input.dir !== 0) {
      const turning = Math.sign(vx) === -input.dir;
      const accel = (onGround ? PLAYER.accelGround : PLAYER.accelAir) * (turning ? 1.8 : 1);
      vx = approach(vx, input.dir * PLAYER.maxSpeed, accel * dt);
      this.facing = input.dir;
    } else {
      vx = approach(vx, 0, (onGround ? PLAYER.frictionGround : PLAYER.frictionAir) * dt);
    }
    body.setVelocityX(vx);

    // --- Saut ---
    if (this.buffer > 0 && this.coyote > 0) {
      body.setVelocityY(-PLAYER.jumpVelocity);
      this.buffer = 0;
      this.coyote = 0;
      this.jumpCuttable = true;
      this.sfx.play('jump');
    }
    if (this.jumpCuttable && body.velocity.y < 0 && !input.jumpHeld) {
      body.setVelocityY(body.velocity.y * PLAYER.jumpCut);
      this.jumpCuttable = false;
    }
    if (body.velocity.y >= 0) this.jumpCuttable = false;
    if (body.velocity.y > PLAYER.maxFallSpeed) body.setVelocityY(PLAYER.maxFallSpeed);

    // --- Animation ---
    if (!onGround) this.anims.play(`${this.color}_jump`, true);
    else if (input.dir !== 0 && Math.abs(vx) > 30) this.anims.play(`${this.color}_walk`, true);
    else this.anims.play(`${this.color}_idle`, true);
    this.setFlipX(this.facing < 0);

    // --- Clignotement d'invincibilité ---
    this.setAlpha(time < this.invincibleUntil ? (Math.floor(time / 90) % 2 ? 0.35 : 1) : 1);
  }

  isInvincible(time: number): boolean {
    return time < this.invincibleUntil;
  }

  /** Rebond après avoir écrasé un ennemi. */
  bounce(): void {
    this.body.setVelocityY(-(this.controls.jumpHeld ? PLAYER.stompBounceHeld : PLAYER.stompBounce));
    this.jumpCuttable = false;
    this.coyote = 0;
  }

  springBounce(): void {
    this.body.setVelocityY(-PLAYER.springBounce);
    this.jumpCuttable = false;
    this.coyote = 0;
  }

  freeze(): void {
    this.frozen = true;
  }

  /** Perte de vie : animation de dégâts + petit saut, sans collision (le joueur tombe hors de l'écran). */
  die(): void {
    this.dead = true;
    this.frozen = false;
    this.body.checkCollision.none = true;
    this.body.setVelocity(0, -PLAYER.deathHop);
    this.setAlpha(1);
    this.setDepth(DEPTH.fx);
    this.anims.play(`${this.color}_hit`, true);
  }

  respawn(x: number, footY: number, time: number): void {
    const y = footY - PLAYER.feetFromCenter * PLAYER.scale;
    this.dead = false;
    this.frozen = false;
    this.body.checkCollision.none = false;
    this.setPosition(x, y);
    this.body.reset(x, y);
    this.setDepth(DEPTH.player);
    this.invincibleUntil = time + PLAYER.invincibleMs;
    this.coyote = 0;
    this.buffer = 0;
    this.facing = 1;
  }
}
