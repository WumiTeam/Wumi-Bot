import Phaser from 'phaser';
import { DEPTH } from '../config';
import type { EnemyDef } from '../data/enemies';

/** Ennemi piloté par sa définition (data/enemies.ts) : marcheur, volant ou obstacle statique. */
export class Enemy extends Phaser.Physics.Arcade.Sprite {
  declare body: Phaser.Physics.Arcade.Body;

  readonly def: EnemyDef;
  dead = false;

  private dir: 1 | -1 = -1;
  private startX: number;
  private t = 0;

  constructor(scene: Phaser.Scene, x: number, footY: number, def: EnemyDef) {
    // Marcheurs : le bas de la hitbox touche le sol. Volants : centrés dans la case.
    const centerY = def.kind === 'flyer' ? footY - 32 : footY - (def.body.oy + def.body.h - 32);
    super(scene, x, centerY, 'enemies', def.frames[0]);
    this.def = def;
    this.startX = x;

    scene.add.existing(this);
    scene.physics.add.existing(this);

    this.setDepth(DEPTH.enemy);
    this.body.setSize(def.body.w, def.body.h, false);
    this.body.setOffset(def.body.ox, def.body.oy);
    this.anims.play(`enemy_${def.id}`);

    if (def.kind === 'walker') {
      this.body.setCollideWorldBounds(true);
    } else {
      this.body.setAllowGravity(false);
      if (def.kind === 'flyer') this.dir = 1;
      else this.body.setImmovable(true);
    }
    this.updateFacing();
  }

  private updateFacing(): void {
    // Le sprite d'origine regarde à gauche ou à droite selon l'ennemi.
    this.setFlipX(this.dir > 0 !== (this.def.faces === 'right'));
  }

  tick(_time: number, delta: number, level: { isGroundAt(x: number, y: number): boolean }): void {
    if (this.dead) return;
    const b = this.body;
    const def = this.def;

    if (def.kind === 'walker') {
      const grounded = b.blocked.down || b.touching.down;
      if (grounded) {
        const hitWall =
          (this.dir < 0 && (b.blocked.left || b.touching.left)) || (this.dir > 0 && (b.blocked.right || b.touching.right));
        const probeX = this.dir < 0 ? b.left - 4 : b.right + 4;
        const ledge = !level.isGroundAt(probeX, b.bottom + 6);
        if (hitWall || ledge) this.dir = (this.dir * -1) as 1 | -1;
      }
      b.setVelocityX(this.dir * def.speed);
      this.updateFacing();
    } else if (def.kind === 'flyer') {
      this.t += delta / 1000;
      const range = def.range ?? 160;
      if (this.x > this.startX + range) this.dir = -1;
      else if (this.x < this.startX - range) this.dir = 1;
      const amp = def.amplitude ?? 30;
      b.setVelocityX(this.dir * def.speed);
      b.setVelocityY(Math.cos(this.t * 2.2) * amp * 2.2);
      this.updateFacing();
    } else {
      this.rotation += delta * 0.008; // scie qui tourne
    }
  }

  /** Ennemi écrasé : il s'aplatit et disparaît (ou tombe s'il n'a pas de frame « écrasé »). */
  squash(): void {
    if (this.dead) return;
    this.dead = true;
    this.body.checkCollision.none = true;
    this.body.setVelocity(0, 0);
    this.anims.stop();

    if (this.def.flat) {
      this.setFrame(this.def.flat);
      this.body.setAllowGravity(false);
      this.scene.tweens.add({
        targets: this,
        alpha: 0,
        delay: 300,
        duration: 300,
        onComplete: () => this.destroy(),
      });
    } else {
      this.setFlipY(true);
      this.body.setAllowGravity(true);
      this.body.setVelocityY(-220);
      this.scene.time.delayedCall(900, () => {
        if (this.active) this.destroy();
      });
    }
  }
}
