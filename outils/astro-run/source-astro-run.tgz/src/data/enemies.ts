/**
 * Définition des ennemis. Pour en ajouter un : ajouter une entrée ici + un caractère dans legend.ts.
 * Les frames viennent de l'atlas « enemies ». Les hitboxes sont en pixels source (64×64).
 */
export interface EnemyDef {
  id: string;
  kind: 'walker' | 'flyer' | 'static';
  /** Frames de l'animation de déplacement. */
  frames: string[];
  fps: number;
  /** Frame « écrasé » (si absent, l'ennemi tombe quand il est vaincu). */
  flat?: string;
  speed: number;
  /** Peut être éliminé en lui sautant dessus. */
  stompable: boolean;
  /** Côté vers lequel regarde le sprite d'origine. */
  faces: 'left' | 'right';
  body: { w: number; h: number; ox: number; oy: number };
  /** Flyer : amplitude verticale (px) et demi-portée de patrouille (px). */
  amplitude?: number;
  range?: number;
}

export const ENEMIES: Record<string, EnemyDef> = {
  slime: {
    id: 'slime',
    kind: 'walker',
    frames: ['slime_normal_walk_a', 'slime_normal_walk_b'],
    fps: 5,
    flat: 'slime_normal_flat',
    speed: 70,
    stompable: true,
    faces: 'left',
    body: { w: 46, h: 38, ox: 9, oy: 26 },
  },
  slimeSpike: {
    id: 'slimeSpike',
    kind: 'walker',
    frames: ['slime_spike_walk_a', 'slime_spike_walk_b'],
    fps: 5,
    speed: 55,
    stompable: false, // le pic sur la tête : impossible à écraser
    faces: 'left',
    body: { w: 46, h: 50, ox: 9, oy: 14 },
  },
  bee: {
    id: 'bee',
    kind: 'flyer',
    frames: ['bee_a', 'bee_b'],
    fps: 12,
    speed: 90,
    stompable: true,
    faces: 'right',
    body: { w: 44, h: 36, ox: 10, oy: 14 },
    amplitude: 40,
    range: 192,
  },
  snail: {
    id: 'snail',
    kind: 'walker',
    frames: ['snail_walk_a', 'snail_walk_b'],
    fps: 4,
    flat: 'snail_shell',
    speed: 40,
    stompable: true,
    faces: 'left',
    body: { w: 48, h: 36, ox: 8, oy: 28 },
  },
  ladybug: {
    id: 'ladybug',
    kind: 'walker',
    frames: ['ladybug_walk_a', 'ladybug_walk_b'],
    fps: 6,
    speed: 85,
    stompable: true,
    faces: 'left',
    body: { w: 48, h: 40, ox: 8, oy: 24 },
  },
  mouse: {
    id: 'mouse',
    kind: 'walker',
    frames: ['mouse_walk_a', 'mouse_walk_b'],
    fps: 8,
    speed: 110,
    stompable: true,
    faces: 'left',
    body: { w: 48, h: 36, ox: 8, oy: 28 },
  },
  saw: {
    id: 'saw',
    kind: 'static',
    frames: ['saw_a', 'saw_b'],
    fps: 10,
    speed: 0,
    stompable: false,
    faces: 'left',
    body: { w: 46, h: 46, ox: 9, oy: 9 },
  },
};
