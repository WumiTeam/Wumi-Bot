/**
 * Légende des niveaux ASCII. Pour créer un niveau, il suffit d'écrire une grille de
 * caractères (1 caractère = 1 tuile de 64 px) avec ces symboles.
 */
export const L = {
  EMPTY: ' ',
  SOLID: '#', // terrain (auto-tuilé selon le thème)
  BRICK: 'B', // brique solide
  QUESTION: '?', // bloc « ! » : donne une pièce quand on le frappe par en dessous
  ONE_WAY: '=', // plateforme traversable par en dessous
  WATER: '~', // eau mortelle
  LAVA: 'v', // lave mortelle
  COIN: 'c',
  PLAYER: 'P',
  DOOR: 'D', // sortie du niveau (porte de 2 tuiles de haut, posée sur cette case)
  CHECKPOINT: 'K',
  SPRING: 'S',
} as const;

/** Caractère → identifiant d'ennemi (voir data/enemies.ts). */
export const ENEMY_CHARS: Record<string, string> = {
  '1': 'slime',
  '2': 'slimeSpike',
  '3': 'bee',
  '4': 'snail',
  '5': 'ladybug',
  '6': 'mouse',
  W: 'saw',
};

/** Caractère → frame de décor dans l'atlas des tuiles. */
export const DECOR_CHARS: Record<string, string> = {
  '*': 'bush',
  '^': 'grass',
  '>': 'sign_right',
  '<': 'sign_left',
  E: 'sign_exit',
  r: 'rock',
  C: 'cactus',
  m: 'mushroom_red',
};
