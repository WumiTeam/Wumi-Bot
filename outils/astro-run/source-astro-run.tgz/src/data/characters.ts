/** Personnages jouables. Les sprites viennent de l'atlas « characters » (character_<couleur>_<frame>). */
export interface CharacterDef {
  id: string;
  name: string;
  /** Couleur dans les noms de frames de l'atlas. */
  color: 'beige' | 'green' | 'pink' | 'purple' | 'yellow';
  /** Prix en pièces (0 = gratuit). Utilisé par la boutique (étape 4). */
  price: number;
}

export const CHARACTERS: CharacterDef[] = [
  { id: 'beige', name: 'Beige', color: 'beige', price: 0 },
  { id: 'green', name: 'Vert', color: 'green', price: 25 },
  { id: 'pink', name: 'Rose', color: 'pink', price: 50 },
  { id: 'purple', name: 'Violet', color: 'purple', price: 80 },
  { id: 'yellow', name: 'Jaune', color: 'yellow', price: 120 },
];

export function getCharacter(id: string | null | undefined): CharacterDef {
  return CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0];
}
