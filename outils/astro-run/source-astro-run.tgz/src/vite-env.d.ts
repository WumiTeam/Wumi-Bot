/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Client ID de l'application Discord (public, sans danger à exposer). */
  readonly VITE_DISCORD_CLIENT_ID?: string;
}
interface ImportMeta {
  readonly env: ImportMetaEnv;
}
